const fs = require("fs");
const assert = require("assert");
const path = require("path");

const app = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const database = fs.readFileSync(path.join(__dirname, "server", "database.mjs"), "utf8");

assert.match(app, /Manager \(optional\)[\s\S]*Assistant Manager \(optional\)/, "Staff form must label both reporting assignments optional");
assert.match(app, /No manager assigned \(optional\)[\s\S]*No assistant manager assigned \(optional\)/, "Staff form must provide explicit unassigned choices");
assert.doesNotMatch(app, /if \(isStaff && !manager\)/, "Local Staff creation must accept no Manager");
assert.doesNotMatch(app, /if \(isStaff && !assistantManager\)/, "Local Staff creation must accept no Assistant Manager");
assert.doesNotMatch(database, /if \(role === "Staff" && !manager\)/, "Secure Staff creation must accept no Manager");
assert.doesNotMatch(database, /if \(role === "Staff" && !assistantManager\)/, "Secure Staff creation must accept no Assistant Manager");
assert.match(app, /\["Cashier", "Executive"\]\.includes\(account\.designation\)[\s\S]*account\.designation === "Staff" && !assignedStaff\.has/, "Other Employees must contain Cashier, Executive and Staff outside Assistant Manager teams");
assert.doesNotMatch(app, /account\.designation !== "Assistant Manager" && !\(/, "Manager and Director must not be swept into Other Employees");

console.log("PASS: Staff reporting assignments are optional and unassigned Staff appear in Other Employees");
