const fs = require("fs");
const path = require("path");
const assert = require("assert");
const JSZip = require("./vendor/jszip.min.js");
const { buildCustomerRepaymentWorkbook } = require("./recovery-demand-xlsx.js");

(async () => {
  const output = await buildCustomerRepaymentWorkbook({
    outputType: "nodebuffer",
    sheetName: "A-05",
    customerCode: "A-05",
    loanId: "G1 (A01-A05)",
    centreName: "CHANDMARI NAGAR",
    centreAddress: "CHANDMARI NAGAR, WATHODA NAGPUR",
    recoveryDay: "Thursday",
    recoveryTime: "10:00",
    customerName: "NAZMIN ASIFUDDIN KAZI",
    guarantorName: "ASIFODDIN GHAYASUDDIN KAZI",
    mobile: "8623975265",
    customerAddress: "PLOT NO. 38 CHANDMARI NAGAR WATHODA NAGPUR",
    loanAmount: 10000,
    disbursementDate: "2024-04-04",
    firstEmiDate: "2024-04-11",
    lastEmiDate: "2024-10-10",
    installments: 26,
    loanPurpose: "SANITARY NAPKINS BUSINESS",
    executiveName: "DINESH DHURVE",
    schedule: [
      { number: 1, date: "2024-04-11", emi: 600, received: "", penalty: "", receipt: "", review: "" },
      { type: "holiday", date: "2024-04-18", holidayName: "BANK HOLIDAY" },
      { type: "closing", number: 2, date: "2024-04-25", emi: 600, received: 1200, penalty: 0, receipt: "R-21", review: "CLOSE" },
    ],
  });
  const zip = await JSZip.loadAsync(output);
  const worksheet = await zip.file("xl/worksheets/sheet1.xml").async("string");
  const styles = await zip.file("xl/styles.xml").async("string");
  const workbook = await zip.file("xl/workbook.xml").async("string");
  const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");

  assert.match(worksheet, /NEELAVATI M\.U\.C\.CO-OP\.S \. LTD\./, "Customer workbook must use the uploaded letterhead");
  assert.match(worksheet, /LOAN ID[\s\S]*G1 \(A01-A05\)[\s\S]*COUSTOMER NAME[\s\S]*NAZMIN ASIFUDDIN KAZI/, "Customer detail block must match A-05 layout");
  assert.match(worksheet, /GUARANTER NAME[\s\S]*ASIFODDIN GHAYASUDDIN KAZI/, "Guarantor details must be included");
  assert.match(worksheet, /COUSTOMER[\s\S]*GUARANTEER/, "Customer and guarantor photo boxes must be present");
  assert.match(worksheet, /<row r="22"[\s\S]*RECIPT[\s\S]*PENALTY[\s\S]*REVIEW[\s\S]*<row r="23"/, "Repayment table must use the sample's two-row header");
  assert.match(worksheet, /EMI RECEIVED/, "Customer repayment workbook must label the received-payment column as EMI RECEIVED");
  assert.doesNotMatch(worksheet, /<t>RD<\/t>/, "Customer repayment workbook must remove the old RD header");
  assert.match(worksheet, /mergeCell ref="J7:K12"/, "Customer photo box must use the uploaded merged-cell placement");
  assert.match(worksheet, /mergeCell ref="J14:K19"/, "Guarantor photo box must use the uploaded merged-cell placement");
  assert.match(styles, /FFB4C6E7/, "Repayment header must use the uploaded light-blue fill");
  assert.match(styles, /FFFFFF00/, "Holiday rows must be highlighted");
  assert.match(workbook, /\$A\$1:\$K\$/, "Print area must cover all eleven sample columns");
  assert.match(appSource, /buildCustomerRepaymentWorkbook/, "Customer Download Excel must call the XLSX builder");
  assert.match(appSource, /link\.download = `\$\{customerCode\}\.xlsx`/, "Downloaded filename must follow A-05.xlsx format");
  assert.doesNotMatch(appSource.slice(appSource.indexOf("async function downloadCustomerSchedule"), appSource.indexOf("function paddedDate")), /csvDownload/, "Customer schedule must no longer download CSV");

  console.log("PASS: Customer Repayment exports as the uploaded A-05 Excel design");
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
