const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: { getItem: () => null, setItem() {}, removeItem() {} },
  document: { querySelector: () => null, querySelectorAll: () => [] },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  bankHolidays = [];
  groups = [
    { code: "GRP-1", number: "G1", name: "Alpha Centre", recoveryStaff: "Brijesh", day: "Monday", members: [{ name: "Asha" }] },
    { code: "GRP-2", number: "G2", name: "Beta Centre", recoveryStaff: "Brijesh", day: "Monday", members: [{ name: "Bina" }] },
    { code: "GRP-3", number: "G3", name: "Gamma Centre", recoveryStaff: "Vijay", day: "Monday", members: [{ name: "Chanda" }] },
  ];
  loans = [
    {
      id: "L1", groupCode: "GRP-1", groupNumber: "G1", groupName: "Alpha Centre", staff: "Brijesh", day: "Monday",
      disbursedOn: "2026-08-31", recoveryStartWeek: "custom", firstRecoveryDate: "2026-09-07",
      individualLoans: [{ memberIndex: 0, amount: 12000, balance: 12000, emi: 600, term: 26 }], recoveries: [],
    },
    {
      id: "L2", groupCode: "GRP-2", groupNumber: "G2", groupName: "Beta Centre", staff: "Brijesh", day: "Monday",
      disbursedOn: "2026-08-31", recoveryStartWeek: "custom", firstRecoveryDate: "2026-09-07",
      individualLoans: [{ memberIndex: 0, amount: 15000, balance: 15000, emi: 700, term: 28 }],
      recoveryProposals: [{ id: "PENDING-G2", status: "Pending", type: "recovery", memberIndex: 0, amount: 700, date: "2026-09-07" }], recoveries: [],
    },
    {
      id: "L3", groupCode: "GRP-3", groupNumber: "G3", groupName: "Gamma Centre", staff: "Vijay", day: "Monday",
      disbursedOn: "2026-08-31", recoveryStartWeek: "custom", firstRecoveryDate: "2026-09-07",
      individualLoans: [{ memberIndex: 0, amount: 20000, balance: 20000, emi: 1000, term: 26 }], recoveries: [],
    },
  ];
  const beforeApproval = todayRecoveryDaybookSnapshot("2026-09-07");
  loans[0].recoveries.push({
    id: "APPROVED-G1", type: "recovery", date: "2026-09-07", amount: 600, principalPaid: 600,
    member: 0, allocations: [{ memberIndex: 0, amount: 600 }], approvedBy: "cashier",
  });
  loans[0].individualLoans[0].balance = 11400;
  const afterFullApproval = todayRecoveryDaybookSnapshot("2026-09-07");
  loans[1].recoveries.push({
    id: "APPROVED-G2-PART", type: "recovery", date: "2026-09-07", amount: 200, principalPaid: 200,
    member: 0, allocations: [{ memberIndex: 0, amount: 200 }], approvedBy: "cashier",
  });
  loans[1].individualLoans[0].balance = 14800;
  const afterPartialApproval = todayRecoveryDaybookSnapshot("2026-09-07");
  globalThis.__result = {
    beforeApproval: JSON.parse(JSON.stringify(beforeApproval)),
    afterFullApproval: JSON.parse(JSON.stringify(afterFullApproval)),
    afterPartialApproval: JSON.parse(JSON.stringify(afterPartialApproval)),
  };
`, context);

const before = context.__result.beforeApproval;
assert.equal(before.inward.length, 2, "Today's Total Recovery must show one line per assigned staff");
assert.equal(before.inward.find((entry) => entry.description === "Brijesh").amount, 1300, "One staff line must total every centre assigned to that staff");
assert.equal(before.inward.find((entry) => entry.description === "Vijay").amount, 1000, "Every recovery staff member must show today's demand total");
assert.deepEqual(before.outward.map((entry) => entry.description), ["G1 · Alpha Centre", "G2 · Beta Centre", "G3 · Gamma Centre"], "Today's Balance Recovery must initially show every due centre");

const afterFull = context.__result.afterFullApproval;
assert.equal(afterFull.inward.find((entry) => entry.description === "Brijesh").amount, 1300, "Today's staff demand must remain fixed after approval");
assert.doesNotMatch(afterFull.outward.map((entry) => entry.description).join("|"), /G1 · Alpha Centre/, "A fully approved centre must disappear from Today's Balance Recovery");
assert.match(afterFull.outward.map((entry) => entry.description).join("|"), /G2 · Beta Centre/, "A pending unapproved centre must remain in Today's Balance Recovery");

const afterPartial = context.__result.afterPartialApproval;
const betaBalance = afterPartial.outward.find((entry) => entry.description === "G2 · Beta Centre");
assert.equal(betaBalance.amount, 500, "A partially approved centre must remain with only its unpaid balance");
assert.match(appSource, /label: isToday \? "Today's Total Recovery" : "Total Recovery"/, "Current Daybook heading must be Today's Total Recovery");
assert.match(appSource, /entry\.source !== "missed-recovery"/, "Today's customer-level missed rows must be replaced by centre-wise balance rows");

console.log("PASS: staff-wise today's demand and approval-driven centre balance recovery");
