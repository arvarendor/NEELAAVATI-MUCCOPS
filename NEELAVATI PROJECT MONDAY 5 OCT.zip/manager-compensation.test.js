const fs = require("fs");
const assert = require("assert");
const path = require("path");

const app = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const database = fs.readFileSync(path.join(__dirname, "server", "database.mjs"), "utf8");

assert.match(app, /isManager[\s\S]*Basic salary and per-file incentive/, "Manager form must show only basic salary and per-file incentive");
assert.match(app, /performanceLabel\?\.classList\.toggle\("hidden", !isStaff\)/, "Only Staff may use the star-performance field");
assert.match(app, /recoveryLabel\?\.classList\.toggle\("hidden", !isStaff\)[\s\S]*businessLabel\?\.classList\.toggle\("hidden", !isStaff\)/, "Manager recovery and business allowance fields must stay hidden");
assert.match(app, /const performanceAllowance = isStaff[\s\S]*const petrolAllowance = isStaff[\s\S]*const businessAllowance = isStaff/, "Manager creation must force all non-incentive benefits to zero");
assert.match(app, /const recovery = component\(isManager \|\| isAssistantManager \? 0[\s\S]*const business = component\(isManager \|\| isAssistantManager \? 0/, "Legacy Manager allowances must not enter live payroll");
assert.match(app, /PERFORMANCE_RATING_ROLES = \["Staff"\]/, "Manager and Assistant Manager must not receive performance star income");
assert.match(app, /isManager \? "File incentive" : "Recovery incentive"/, "Manager My Working must label the earning as file incentive");
assert.match(database, /performanceAllowance = role === "Staff"[\s\S]*petrolAllowance = role === "Staff"[\s\S]*businessAllowance = role === "Staff"/, "Secure backend must store only Manager basic salary, incentive, and RD");
assert.match(database, /\["Manager", "Assistant Manager"\]\.includes\(row\.role\) \? 0[\s\S]*\["Manager", "Assistant Manager"\]\.includes\(row\.role\) \? 0/, "Secure working profile must suppress historical Manager allowances");

console.log("PASS: Manager compensation is limited to basic salary and per-file incentive");
