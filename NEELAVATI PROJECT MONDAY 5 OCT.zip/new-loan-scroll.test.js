const fs = require("fs");
const path = require("path");
const assert = require("assert");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const openNewLoanSource = appSource.slice(
  appSource.indexOf("function openNewLoan()"),
  appSource.indexOf("function editLoanRecord")
);

assert.match(openNewLoanSource, /placeLoanFormBelowPageHeader\(\)/, "New Group Loan must place its form directly below the Loan Record page header");
assert.doesNotMatch(openNewLoanSource, /scrollIntoView/, "New Group Loan must never auto-scroll the page to the bottom");
assert.doesNotMatch(appSource, /scrollIntoView/, "No action may automatically scroll the page downward");
assert.match(appSource, /pageHeader\.insertAdjacentElement\("afterend", loanForm\)/, "Loan form must open next to the button area instead of at the bottom of the record list");
assert.match(openNewLoanSource, /pendingGroups\s*=\s*groups\.filter\(\(group\)\s*=>\s*!loanForGroup\(group\)\)/, "New Group Loan must list only groups that have not been disbursed");
assert.doesNotMatch(appSource, /loan already disbursed/i, "Disbursed groups must not be shown in the New Group Loan selection");

const openHoldSource = appSource.slice(
  appSource.indexOf("function openHoldEntry"),
  appSource.indexOf("function saveHoldEntry")
);
assert.doesNotMatch(openHoldSource, /scrollIntoView/, "Hold Release and Edit must never auto-scroll the page to the bottom");
assert.match(openHoldSource, /classList\.add\("hold-entry-dialog"\)/, "Hold Release must open as a fixed in-view dialog");

console.log("PASS: New Group Loan and Hold Release open without automatic page scrolling");
