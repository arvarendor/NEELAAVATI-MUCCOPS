const fs = require("fs");
const assert = require("assert");
const path = require("path");

const html = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const app = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const database = fs.readFileSync(path.join(__dirname, "server", "database.mjs"), "utf8");

assert.match(html, /data-page="working"[\s\S]*<span>My Working<\/span>/, "My Working must be a separate core navigation feature");
assert.match(html, /<section id="working" class="page">[\s\S]*id="myWorkingContent"/, "My Working must contain the role-aware working dashboard");
assert.match(app, /const DEFAULT_TEAM_RECOVERY_INCENTIVE_RATE = 15/, "New Manager and Assistant Manager accounts must start with a ₹15 team incentive suggestion");
assert.match(app, /function saveTeamIncentive\(view, encodedLoginId\)/, "Director must be able to edit an Assistant Manager's team incentive rate");
assert.match(app, /function assignedTeamStaff\(account\)/, "The display must resolve each Manager or Assistant Manager's assigned Staff");
assert.match(app, /managerIncentiveRate: recoveryIncentiveRate\(assignedManager\)[\s\S]*assistantManagerIncentiveRate: recoveryIncentiveRate\(assignedAssistantManager\)/, "A Staff proposal must retain the editable Manager and Assistant Manager incentive rates");
assert.match(app, /function teamIncentiveEvents\(account\)[\s\S]*approvedStaffRecoveryRows\(\)[\s\S]*const key = `\$\{date\}\|\$\{centreKey\}`/, "Team incentive must use approved Staff recoveries and de-duplicate each centre per date");
assert.match(app, /Manager: \[[^\]]*"working"/, "Manager must have access to the My Working core feature");
assert.match(app, /"Assistant Manager": \["verification", "recovery", "working", "team-target"\]/, "Assistant Manager must have My Working, team target and team Recovery Demand access");
assert.match(app, /function renderMyWorking\(\)[\s\S]*"Staff", "Manager", "Assistant Manager"[\s\S]*renderEmployeeWorking/, "One role-aware dashboard must render inside My Working");
assert.match(database, /const incentive = extendedCompensation \? amount\("incentive"\) : 0/, "Secure employee creation must save the editable team incentive rate");
assert.equal(50 * 27, 1350, "50 approved centres at an editable ₹27 rate must earn ₹1,350");

console.log("PASS: assigned Manager and Assistant Manager earn their editable rate per approved Staff centre recovery");
