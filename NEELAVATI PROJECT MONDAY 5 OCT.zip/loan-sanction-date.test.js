const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
const storage = new Map();
const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: {
    querySelector: () => null,
    querySelectorAll: () => [],
    createElement: () => ({ classList: { add() {}, remove() {} } }),
  },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  globalThis.__result = {
    explicit: loanSanctionDate({ sanctionDate: "2026-08-22", disbursedOn: "2026-08-20T12:00:00.000Z" }),
    legacy: loanSanctionDate({ disbursedOn: "2026-07-15T12:00:00.000Z" }),
    missing: loanSanctionDate(null),
  };
`, context);

assert.equal(context.__result.explicit, "2026-08-22", "Stored sanction date must be displayed");
assert.equal(context.__result.legacy, "2026-07-15", "Existing loans must use their original disbursement date as sanction date");
assert.equal(context.__result.missing, "", "Missing loans must not invent a date");
assert.match(appSource, /<span>Loan Sanction Date<\/span><b>\$\{loan \? dateText\(loanSanctionDate\(loan\)\) : "Not sanctioned"\}/, "Group Folder must show Loan Sanction Date");
assert.match(appSource, /sanctionDate: selectedSanctionDate \|\| previousLoan\?\.sanctionDate \|\| String\(previousLoan\?\.disbursedOn \|\| todayIso\(\)\)\.slice\(0, 10\)/, "Loans must store the stable sanction date, including Director-selected historical dates");

console.log("PASS: Group Folder shows and preserves Loan Sanction Date");
