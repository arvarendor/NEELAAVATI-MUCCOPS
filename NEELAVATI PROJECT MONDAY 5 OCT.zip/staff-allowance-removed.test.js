const fs = require("fs");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const htmlSource = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const cssSource = fs.readFileSync(path.join(__dirname, "style.css"), "utf8");

assert.doesNotMatch(htmlSource, /data-page="allowance"|data-go="allowance"|id="allowance"/i, "Staff Allowance navigation and page must be removed");
assert.doesNotMatch(htmlSource, /employeeDailyAllowance|Daily allowance|allowancePopup/i, "Employee allowance controls and popup must be removed");
assert.doesNotMatch(cssSource, /\.allowance[-\w]*/i, "Staff Allowance styles must be removed");
assert.doesNotMatch(appSource, /staffAllowances|renderStaffAllowance|depositNextDayAllowance|issueStaffAllowance|receiveStaffAllowance/, "Staff Allowance runtime must be removed");
assert.doesNotMatch(appSource, /scrollIntoView/, "No option may automatically scroll the page downward");

assert.match(appSource, /localStorage\.removeItem\("nmcStaffAllowances"\)/, "Legacy Staff Allowance storage must be removed during startup");
assert.match(appSource, /entry\?\.source !== "staff-allowance"/, "Legacy Staff Allowance Cashbook entries must be cleaned during startup");

console.log("PASS: Staff Allowance is removed everywhere and all automatic downward scrolling is disabled");
