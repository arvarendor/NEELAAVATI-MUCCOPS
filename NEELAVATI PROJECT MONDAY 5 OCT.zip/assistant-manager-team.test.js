const fs = require("fs");
const assert = require("assert");
const path = require("path");

const app = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const api = fs.readFileSync(path.join(__dirname, "api.js"), "utf8");
const server = fs.readFileSync(path.join(__dirname, "server", "server.mjs"), "utf8");
const database = fs.readFileSync(path.join(__dirname, "server", "database.mjs"), "utf8");

assert.match(app, /function assignStaffToAssistantManager\(view, encodedAssistantLoginId\)/, "Director must be able to assign or move Staff inside an Assistant Manager folder");
assert.match(app, /staff\.assistantManagerLoginId = assistant\.loginId[\s\S]*staff\.assistantManagerName = assistant\.name/, "Local Staff records must keep exactly one Assistant Manager assignment");
assert.match(api, /assignStaffAssistantManager\(id, assistantManagerLoginId\)[\s\S]*\/assistant-manager/, "Secure API must expose Assistant Manager team assignment");
assert.match(server, /userAssistantManagerMatch[\s\S]*store\.assignStaffAssistantManager/, "Secure server must route Assistant Manager team assignment");
assert.match(database, /UPDATE users SET assistant_manager_user_id = \?/, "Secure database must replace the single Assistant Manager foreign key");
assert.match(app, /const VERIFICATION_ALLOWANCE_PER_STAFF = 2000/, "Verification allowance must be ₹2,000 per assigned Staff");
assert.match(app, /assignedStaffCount \* VERIFICATION_ALLOWANCE_PER_STAFF/, "Assistant Manager verification allowance must scale with team size");
assert.match(app, /const verification = component\(/, "Verification allowance must use the same per-day attendance calculation");
assert.match(app, /isManager \|\| isAssistantManager \? 0 : account\?\.petrolAllowance[\s\S]*isManager \|\| isAssistantManager \? 0 : account\?\.businessAllowance/, "Manager and Assistant Manager must not receive recovery or business allowance");
assert.match(app, /salaryBeforeDeposit = basic\.net \+ recovery\.net \+ business\.net \+ verification\.net \+ performance/, "Live salary must include verification and automatic performance before RD deduction");
assert.equal(3 * 2000, 6000, "Three assigned Staff must generate ₹6,000 verification allowance");
assert.equal(4 * 2000, 8000, "Four assigned Staff must generate ₹8,000 verification allowance");
assert.ok(Math.abs(((8000 / 30) * 29) - 7733.333333333333) < 0.001, "One absent day must reduce an ₹8,000 verification allowance by its daily rate");

console.log("PASS: Assistant Manager teams, editable incentive and attendance-based verification allowance are enforced");
