const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const htmlSource = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
const storage = new Map();
const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: {
    querySelector: () => null,
    querySelectorAll: () => [],
    createElement: () => ({ classList: { add() {}, remove() {} } }),
  },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  const snapshot = { demand: 3000, emi: 1000, balance: 15000 };
  globalThis.__result = {
    advance: inlineRecoveryDefaultAmount("advance", snapshot),
    recovery: inlineRecoveryDefaultAmount("recovery", snapshot),
    closing: inlineRecoveryDefaultAmount("closing", snapshot),
  };
`, context);

assert.equal(context.__result.advance, 0, "Advance Recovery must always start at zero for manual staff entry");
assert.equal(context.__result.recovery, 3000, "Normal recovery may continue to show the current demand");
assert.equal(context.__result.closing, 15000, "Closing may continue to show the outstanding balance");
assert.doesNotMatch(appSource, /const advanceAmount\s*=/, "Advance amount must not be calculated automatically in the customer row");
assert.doesNotMatch(appSource, /updateAdvanceRecoveryAmount/, "No automatic advance amount updater may remain");
assert.doesNotMatch(htmlSource, /entryAdvanceWeeks/, "Unused automatic future-week selector must be removed");

console.log("PASS: Advance Recovery stays at 0 until staff manually enters an amount");
