const fs = require("fs");
const assert = require("assert");
const path = require("path");

const html = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const app = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const database = fs.readFileSync(path.join(__dirname, "server", "database.mjs"), "utf8");

[
  "employeeManager",
  "employeeAssistantManager",
  "employeeSalary",
  "employeePerformanceAllowance",
  "employeePetrolAllowance",
  "employeeBusinessAllowance",
  "employeeIncentive",
].forEach((id) => assert.match(html, new RegExp(`id=["']${id}["']`), `${id} control is required`));

assert.match(app, /account\.designation === "Manager"/, "Only active Manager accounts populate the manager selector");
assert.match(app, /account\.designation === "Assistant Manager"/, "Only active Assistant Manager accounts populate the assistant selector");
assert.match(app, /Manager and Assistant Manager are optional/, "Staff creation must allow both reporting assignments to remain empty");
assert.doesNotMatch(app, /if \(isStaff && !manager\)/, "Local Staff creation must not require a Manager");
assert.doesNotMatch(app, /if \(isStaff && !assistantManager\)/, "Local Staff creation must not require an Assistant Manager");
assert.doesNotMatch(database, /if \(role === "Staff" && !manager\)/, "Secure Staff creation must not require a Manager");
assert.doesNotMatch(database, /if \(role === "Staff" && !assistantManager\)/, "Secure Staff creation must not require an Assistant Manager");
assert.match(app, /managerLoginId[\s\S]*assistantManagerLoginId[\s\S]*performanceAllowance[\s\S]*petrolAllowance[\s\S]*businessAllowance[\s\S]*incentive/, "Staff reporting and employment amounts are saved with the account");
assert.match(app, /isManager[\s\S]*Basic salary and per-file incentive/, "Manager must use the basic-salary and per-file-incentive format");
assert.match(database, /manager_user_id INTEGER REFERENCES users\(id\)/, "Secure database links staff to a manager account");
assert.match(database, /assistant_manager_user_id INTEGER REFERENCES users\(id\)/, "Secure database links staff to an assistant manager account");
assert.match(database, /performance_allowance INTEGER NOT NULL DEFAULT 0/, "Secure database stores staff compensation details");
assert.match(app, /location\.protocol === "file:" \|\| location\.hostname\.endsWith\("\.chatgpt\.site"\)/, "Static login fallback is limited to local files and the private Sites demo host");

console.log("PASS: role-based salary formats and Staff reporting assignments are enforced");
