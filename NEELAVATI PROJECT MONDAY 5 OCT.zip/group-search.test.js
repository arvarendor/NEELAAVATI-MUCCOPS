const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
const storage = new Map();
const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: {
    querySelector: () => null,
    querySelectorAll: () => [],
    createElement: () => ({ classList: { add() {}, remove() {} } }),
  },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  groups = [{
    code: "GRP-8",
    number: "G8",
    name: "Chandmari Nagar",
    members: [
      { name: "Nazmin Kazi" },
      { name: "Shahin Salam" },
      { name: "Farida Customer" },
      { name: "Rehana Shaikh" },
      { name: "Sunita More" },
    ],
  }];
  const searchableLoan = {
    groupCode: "GRP-8",
    groupNumber: "G8",
    groupName: "Chandmari Nagar",
    head1: "Nazmin Kazi",
    head2: "Shahin Salam",
    individualLoans: [{ memberIndex: 2 }],
  };
  const customerValues = loanCustomerSearchValues(searchableLoan);
  globalThis.__result = {
    exactG1: matchesGroupSearch("G1", "G1", ["Chandmari Nagar"]),
    excludesG10: matchesGroupSearch("G1", "G10", ["Another Centre"]),
    excludesG11: matchesGroupSearch("G1", "G11", ["Third Centre"]),
    lowercase: matchesGroupSearch("g1", "G1", []),
    numberOnly: matchesGroupSearch("1", "G1", []),
    trimmed: matchesGroupSearch("  G1  ", "G1", []),
    centreText: matchesGroupSearch("chandmari", "G8", ["Chandmari Nagar"]),
    headText: matchesGroupSearch("nazmin", "G8", ["Centre", "Nazmin Kazi"]),
    thirdCustomerText: matchesGroupSearch("farida", searchableLoan.groupNumber, customerValues),
    fifthCustomerText: matchesGroupSearch("sunita more", searchableLoan.groupNumber, customerValues),
    customerValues,
  };
`, context);

assert.equal(context.__result.exactG1, true, "G1 must match G1");
assert.equal(context.__result.excludesG10, false, "G1 must not match G10");
assert.equal(context.__result.excludesG11, false, "G1 must not match G11");
assert.equal(context.__result.lowercase, true, "Group search must be case-insensitive");
assert.equal(context.__result.numberOnly, true, "Entering 1 must find exact group G1");
assert.equal(context.__result.trimmed, true, "Surrounding spaces must be ignored");
assert.equal(context.__result.centreText, true, "Centre name search must remain available");
assert.equal(context.__result.headText, true, "Group head search must remain available in Loan Record");
assert.equal(context.__result.thirdCustomerText, true, "Loan Record must find a non-head customer by name");
assert.equal(context.__result.fifthCustomerText, true, "Search must include every customer in the group");
assert.ok(context.__result.customerValues.includes("Farida Customer"), "Loan search values must contain all verification member names");
assert.match(appSource, /function renderLoans\(\)[\s\S]*?matchesGroupSearch\(query, loan\.groupNumber/, "Loan Record must use exact group search");
assert.match(appSource, /function renderHoldLoans\(\)[\s\S]*?matchesGroupSearch\(query, loan\.groupNumber/, "Hold Loan must use exact group search");
assert.match(appSource, /function renderGroups\(\)[\s\S]*?\.\.\.\(group\.members \|\| \[\]\)\.map\(\(member\) => member\.name\)/, "Verification search must include every customer name");
assert.match(appSource, /function renderHoldLoans\(\)[\s\S]*?loanCustomerSearchValues\(loan\)/, "Hold Loan must search by customer name");

console.log("PASS: exact Group ID and all-customer-name search across Verification, Loan Record, and Hold Loan");
