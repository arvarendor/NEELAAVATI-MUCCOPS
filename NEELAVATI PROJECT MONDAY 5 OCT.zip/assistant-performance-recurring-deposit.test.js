const fs = require("fs");
const assert = require("assert");
const path = require("path");

const app = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const api = fs.readFileSync(path.join(__dirname, "api.js"), "utf8");
const server = fs.readFileSync(path.join(__dirname, "server", "server.mjs"), "utf8");
const database = fs.readFileSync(path.join(__dirname, "server", "database.mjs"), "utf8");

assert.match(app, /PERFORMANCE_RATING_ROLES = \["Staff"\]/, "Assistant Manager must not use star ratings");
assert.match(app, /ASSISTANT_PERFORMANCE_FILE_TARGET = 12[\s\S]*ASSISTANT_PERFORMANCE_PER_QUALIFIED_STAFF = 2000/, "Each Staff completing 12 disbursed files must add ₹2,000 performance allowance");
assert.match(app, /assistantManagerPerformanceDetails\(account, month\)[\s\S]*qualifiedStaff \* ASSISTANT_PERFORMANCE_PER_QUALIFIED_STAFF/, "Assistant Manager performance must scale only with qualifying team Staff");
assert.match(app, /total: netSalary/, "Net salary must exclude incentive");
assert.match(app, /salaryBeforeDeposit[\s\S]*recurringDepositDeduction[\s\S]*netSalary/, "RD must be deducted before net salary is calculated");
assert.match(app, /recurringDepositStartedAt[\s\S]*recurringDeposit\.months > 0[\s\S]*Math\.min\(salaryBeforeDeposit, recurringDeposit\.monthly\)/, "A saved RD start month must automatically deduct the same amount in every applicable salary month");
assert.match(app, /Auto every month from[\s\S]*Enter once to start automatic monthly deduction/, "RD register must explain that one saved amount repeats every month");
assert.match(app, /RECURRING_DEPOSIT_ANNUAL_RATE = 0\.12[\s\S]*monthlyRate = RECURRING_DEPOSIT_ANNUAL_RATE \/ 12/, "RD must show a 12% annual rate using monthly calculation");
assert.match(app, /data-employee-view="recurring-deposit"[\s\S]*id="recurringDepositRows"/, "Employee Management must include a Recurring Deposit register next to Salary Book");
assert.match(app, /Incentive \(separate\)[\s\S]*RD deduction[\s\S]*Net salary/, "Salary Book must separate incentive and display RD before net salary");
assert.match(api, /updateRecurringDeposit\(id, recurringDeposit\)/, "Secure API must update monthly RD settings");
assert.match(server, /userRecurringDepositMatch[\s\S]*store\.updateRecurringDeposit/, "Secure server must route RD updates");
assert.match(database, /recurring_deposit INTEGER NOT NULL DEFAULT 0[\s\S]*recurring_deposit_started_at TEXT[\s\S]*Only the Director can update recurring deposits/, "Secure database must persist Director-controlled monthly RD values and their start month");
assert.match(database, /roundedAmount > 0 \? existingStartMonth : null[\s\S]*recurring_deposit_started_at/, "Updating an active RD must retain its original start month while zero stops it");

assert.equal(3 * 2000, 6000, "Three qualifying Staff must earn ₹6,000 for the Assistant Manager");
assert.equal(4 * 2000, 8000, "Four qualifying Staff must earn ₹8,000 for the Assistant Manager");

console.log("PASS: automatic Assistant Manager performance and separate 12% recurring deposit payroll rules");
