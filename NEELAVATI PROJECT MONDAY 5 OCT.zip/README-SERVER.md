# NEELAVATI MUCCOPS secure server

The backend uses Node.js 24's built-in SQLite driver. Customer application state is encrypted with AES-256-GCM before it is written to SQLite. Passwords are stored as salted scrypt hashes. Sessions use random HttpOnly, SameSite cookies, every mutation requires a CSRF token, and application writes are checked against the signed-in role.

## Local test

```powershell
npm run test:backend
npm start
```

The local development login is `shubham` with the existing development password. The default is disabled when `NODE_ENV=production`.

## Production requirements

Set every value shown in `.env.example` through the hosting provider's secret manager. Do not commit a real password, password pepper, encryption key, database, or backup. Put the Node server behind HTTPS, restrict it to the intended employees, and back up both the database and encryption key in separate protected locations.

This is a technical security baseline, not a regulatory certification. Before storing Aadhaar, photos, addresses, or live loan records, obtain a professional security review and confirm applicable Indian privacy, lending, retention, and audit requirements.
