const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const htmlSource = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
const storage = new Map();
const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: { querySelector: () => null, querySelectorAll: () => [] },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  bankHolidays = [];
  const loan = {
    recoveryStartWeek: "custom",
    firstRecoveryDate: "2026-01-05",
    disbursedOn: "2025-12-29",
    day: "Monday",
    term: 26,
  };
  const customer = { holdAmount: 2000, holdTransactions: [] };
  const beforeWeek12 = holdReleasePlan(loan, customer, "2026-03-22", "Staff");
  const onWeek12 = holdReleasePlan(loan, customer, "2026-03-23", "Staff");
  customer.holdTransactions.push({ amount: 1000, date: "2026-03-23" });
  const afterFirstPart = holdReleasePlan(loan, customer, "2026-03-24", "Staff");
  const onWeek20 = holdReleasePlan(loan, customer, "2026-05-18", "Staff");
  customer.holdTransactions = [];
  const directorEmergency = holdReleasePlan(loan, customer, "2026-02-01", "Director");
  bankHolidays = [{ date: "2026-03-23", name: "Bank holiday" }];
  const shiftedWeek12 = holdReleaseMilestoneDate(loan, 12);
  globalThis.__result = {
    beforeWeek12,
    onWeek12,
    afterFirstPart,
    onWeek20,
    directorEmergency,
    shiftedWeek12,
    parts: [2000, 3000, 4000, 5000].map((holdAmount) => holdReleasePartAmount({ holdAmount })),
  };
`, context);

assert.equal(context.__result.beforeWeek12.entryLimit, 0, "Staff must not release hold before week 12");
assert.equal(context.__result.beforeWeek12.eligible, false, "Staff release must remain locked before week 12");
assert.equal(context.__result.onWeek12.entryLimit, 1000, "₹2,000 hold must release as a ₹1,000 first part at week 12");
assert.equal(context.__result.afterFirstPart.entryLimit, 0, "Second part must stay locked after the week-12 half is released");
assert.equal(context.__result.afterFirstPart.nextWeek, 20, "The next eligible milestone must be week 20");
assert.equal(context.__result.onWeek20.entryLimit, 1000, "The remaining ₹1,000 must unlock at week 20");
assert.equal(context.__result.directorEmergency.entryLimit, 2000, "Director must be able to release the hold balance at any time");
assert.equal(context.__result.directorEmergency.eligible, true, "Director emergency release must remain available before week 12");
assert.equal(context.__result.shiftedWeek12, "2026-03-30", "A bank holiday must shift the week-12 release milestone with the recovery schedule");
assert.deepEqual(Array.from(context.__result.parts), [1000, 1500, 2000, 2500], "Hold slabs must be split into two equal parts");
assert.match(appSource, /amount > releasePlan\.entryLimit/, "Save must reject a non-Director amount above the unlocked part");
assert.match(appSource, /Director emergency hold release/, "Emergency Director releases must be marked in history");
assert.match(htmlSource, /id="holdReleaseRule"/, "Hold release form must show the week-12 and week-20 rule");

console.log("PASS: Hold Loan releases half after week 12, half after week 20, with Director emergency override");
