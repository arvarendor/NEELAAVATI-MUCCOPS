const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const htmlSource = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
const storage = new Map();
const elements = new Map([
  ["#newDebitVoucher", { style: {} }],
  ["#currentDaybookDate", { textContent: "" }],
  ["#daybookSheets", { innerHTML: "" }],
  ["#cashDescription", { value: "Fresh bank cash intake" }],
  ["#cashAmount", { value: "5000" }],
  ["#cashForm", { classList: { add() {}, remove() {} } }],
]);
const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: {
    querySelector: (selector) => elements.get(selector) || null,
    querySelectorAll: () => [],
    createElement: () => ({ className: "", remove() {}, classList: { add() {}, remove() {} } }),
  },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  todayIso = () => "2026-07-08";
  groups = [
    { code: "GRP-1", number: "G1", name: "Test Centre", members: [{ name: "Alice" }] },
    { code: "GRP-2", number: "G2", name: "Closed Centre", members: [{ name: "Bina" }] },
  ];
  loans = [
    {
      id: "LOAN-1",
      groupCode: "GRP-1",
      groupNumber: "G1",
      groupName: "Test Centre",
      amount: 12000,
      disbursedOn: "2026-07-01",
      day: "Wednesday",
      individualLoans: [{
        memberIndex: 0,
        amount: 12000,
        balance: 11850,
        emi: 1000,
        term: 12,
        processingFee: 600,
        processingFeeReason: "Standard processing fee",
        holdAmount: 2000,
        holdTransactions: [{ id: "HOLD-1", date: "2026-07-05", amount: 500, note: "First hold release" }],
      }],
      recoveries: [{
        id: "REC-1",
        type: "recovery",
        date: "2026-07-08",
        demandDate: "2026-07-01",
        amount: 200,
        principalPaid: 150,
        penaltyPaid: 50,
        member: 0,
        allocations: [{ memberIndex: 0, amount: 200 }],
        receipt: "R-1",
      }],
    },
    {
      id: "LOAN-2",
      groupCode: "GRP-2",
      groupNumber: "G2",
      groupName: "Closed Centre",
      amount: 15000,
      disbursedOn: "2026-07-01",
      day: "Thursday",
      individualLoans: [{
        memberIndex: 0,
        amount: 15000,
        balance: 0,
        emi: 700,
        term: 28,
        processingFee: 930,
        processingFeeReason: "Standard processing fee",
        holdAmount: 3000,
        holdTransactions: [],
        closedAt: "2026-07-20",
      }],
      recoveries: [
        { id: "REC-2", type: "advance", date: "2026-07-10", amount: 2100, principalPaid: 2100, penaltyPaid: 0, member: 0, allocations: [{ memberIndex: 0, amount: 2100 }] },
        { id: "REC-4", type: "recovery", date: "2026-07-11", amount: 300, principalPaid: 300, penaltyPaid: 0, member: 0, allocations: [{ memberIndex: 0, amount: 300 }] },
        { id: "REC-3", type: "closing", date: "2026-07-20", amount: 5000, principalPaid: 5000, penaltyPaid: 0, member: 0, allocations: [{ memberIndex: 0, amount: 5000 }] },
      ],
    },
  ];
  cashEntries = [{ id: "MANUAL-1", date: "2026-07-08", description: "Bank cash intake", amount: 50000, type: "credit", source: "cash-intake" }];
  syncAutomaticCashbookEntries("2026-07-08");
  const first = JSON.parse(JSON.stringify(cashEntries));
  syncAutomaticCashbookEntries("2026-07-08");
  const second = JSON.parse(JSON.stringify(cashEntries));
  loans[0].individualLoans[0].holdTransactions[0].amount = 700;
  loans[0].recoveries[0].amount = 1050;
  loans[0].recoveries[0].principalPaid = 1000;
  syncAutomaticCashbookEntries("2026-07-08");
  currentUser = { name: "Test Cashier", loginId: "cashier-1", designation: "Cashier" };
  renderCashbook();
  const renderedDaybook = document.querySelector("#daybookSheets").innerHTML;
  renderCashbook = () => {};
  addActivity = () => {};
  toast = () => {};
  saveCashEntry();
  document.querySelector("#cashDescription").value = "";
  document.querySelector("#cashAmount").value = "250";
  saveCashEntry();
  currentUser = { name: "Test Staff", loginId: "staff-1", designation: "Staff" };
  document.querySelector("#cashDescription").value = "Blocked cash intake";
  document.querySelector("#cashAmount").value = "999";
  saveCashEntry();
  globalThis.__result = {
    first,
    second,
    updated: JSON.parse(JSON.stringify(cashEntries)),
    stored: JSON.parse(localStorage.getItem(STORAGE.cashbook) || "[]"),
    renderedDaybook,
  };
`, context);

const bySource = (entries, source) => entries.filter((entry) => entry.source === source);
assert.equal(context.__result.first.length, context.__result.second.length, "Repeated synchronization must not duplicate entries");
assert.equal(bySource(context.__result.first, "cash-intake").length, 1, "Manual cash intake must be preserved");
assert.equal(bySource(context.__result.first, "loan-disbursement")[0].amount, 10000, "Disbursement must post net of held amount");
assert.equal(bySource(context.__result.first, "loan-processing-fee").length, 2, "Each group must create exactly one consolidated processing entry");
assert.equal(bySource(context.__result.first, "loan-processing-fee").reduce((sum, entry) => sum + entry.amount, 0), 1530, "Processing entries must equal the customer-wise fee total");
assert.equal(bySource(context.__result.first, "loan-processing-fee")[0].type, "credit", "Processing fees must post as Inward");
assert.equal(bySource(context.__result.first, "loan-processing-fee")[0].daybookCategory, "processing", "Processing fees must use the Processing heading");
assert.ok(bySource(context.__result.first, "loan-processing-fee").every((entry) => entry.autoKey.endsWith(":group")), "Cashbook must store processing as one group-level amount");
assert.equal(bySource(context.__result.first, "hold-release")[0].amount, 500, "Hold release must post Outward");
assert.equal(bySource(context.__result.first, "recovery")[0].amount, 150, "Recovery principal must post Inward");
assert.equal(bySource(context.__result.first, "recovery")[0].daybookCategory, "total-recovery", "A normal recovery received on the centre weekday must update Total Recovery even when it clears an earlier demand");
assert.equal(bySource(context.__result.first, "recovery")[0].collectionWeekday, "Wednesday", "The automatic Cashbook entry must retain its collection weekday");
assert.equal(bySource(context.__result.first, "recovery")[0].scheduledRecoveryDay, "Wednesday", "The automatic Cashbook entry must retain the centre recovery day");
assert.equal(bySource(context.__result.first, "penalty-recovery")[0].amount, 50, "Paid penalty must post separately as Inward");
assert.equal(bySource(context.__result.first, "penalty-recovery")[0].daybookCategory, "penalty", "Paid penalty must use its own Penalty heading");
assert.equal(bySource(context.__result.first, "advance-recovery")[0].type, "credit", "Advance recovery must post Inward");
assert.equal(bySource(context.__result.first, "loan-closing")[0].type, "credit", "Closing must post Inward");
assert.equal(bySource(context.__result.first, "advance-recovery")[0].daybookCategory, "advance", "Advance must use the Advance Recovery heading");
assert.equal(bySource(context.__result.first, "loan-closing")[0].daybookCategory, "closing", "Closing must use the Closing heading");
assert.equal(bySource(context.__result.first, "recovery").find((entry) => entry.sourceId.includes("REC-4")).daybookCategory, "later-recovery", "Off-day recovery must use the Later Recovery heading");
assert.equal(bySource(context.__result.first, "missed-recovery")[0].amount, 850, "Unreceived part of today's EMI must post Outward");
assert.equal(bySource(context.__result.first, "missed-recovery")[0].daybookCategory, "balance-recovery", "Today's unpaid recovery must use the Balance Recovery heading");
assert.equal(bySource(context.__result.updated, "hold-release")[0].amount, 700, "Edited hold release must update its Outward entry");
assert.equal(bySource(context.__result.updated, "recovery").filter((entry) => entry.daybookCategory === "total-recovery").reduce((sum, entry) => sum + entry.amount, 0), 1000, "Total Recovery must automatically recalculate from the latest approved scheduled-day amount");
assert.equal(bySource(context.__result.updated, "missed-recovery").filter((entry) => String(entry.sourceId).startsWith("LOAN-1:")).length, 0, "A same-day missed recovery must clear after that day's EMI is received");
assert.ok(bySource(context.__result.updated, "missed-recovery").some((entry) => String(entry.sourceId).startsWith("LOAN-2:")), "A closed loan must retain its earlier historical Balance Recovery snapshot");
assert.equal(context.__result.updated.length, context.__result.stored.length, "Synchronized ledger must persist on the device");
assert.equal(bySource(context.__result.updated, "cash-intake").length, 3, "Cash Intake option must add entries without allowing Staff access");
assert.equal(bySource(context.__result.updated, "cash-intake").at(-1).type, "credit", "Cash Intake must always post as Inward");
assert.equal(bySource(context.__result.updated, "cash-intake").at(-1).date, "2026-07-08", "Cash Intake must use today's automatic Daybook date");
assert.equal(bySource(context.__result.updated, "cash-intake").at(-1).description, "Cash intake", "Cash Intake note must be optional");
assert.match(htmlSource, /id="daybookSheets"/, "Cashbook must contain daily Daybook sheets");
assert.match(appSource, /label: "Closing"/, "Inward Daybook must contain the Closing heading");
assert.match(appSource, /label: "Late Recovery"/, "Daybook must use the Late Recovery heading");
assert.match(appSource, /label: "Penalty"/, "Inward Daybook must contain a separate Penalty heading");
assert.match(appSource, /label: "Processing"/, "Inward Daybook must contain the Processing heading");
assert.match(appSource, /loan-processing-fee:\$\{loanKey\}:group/, "Cashbook processing must use one consolidated group entry");
assert.match(appSource, /label: "Hold Loan Deduction"/, "Outward Daybook must use the Hold Loan Deduction heading");
assert.doesNotMatch(appSource, /label: "Pending Disbursement"/, "Pending Disbursement heading must be removed");
assert.match(appSource, /"Today's Balance Recovery"/, "Today's Outward Daybook must contain the Today's Balance Recovery heading");
assert.doesNotMatch(appSource, /label: "Pending Recovery"/, "Pending Recovery heading must be removed");
assert.match(htmlSource, /<h1>Daybook<\/h1>/, "Cashbook page title must be Daybook");
assert.doesNotMatch(htmlSource, /<h1>Daily daybook<\/h1>|Entry type<input value="INWARD/, "Daybook must remove the old title and Cash Intake entry-type field");
assert.match(htmlSource, /<label>Amount<input id="cashAmount"[\s\S]*<label>Note<input id="cashDescription"/, "Cash Intake form must contain only Amount and Note fields");
assert.match(htmlSource, /Today's date will be applied automatically/, "Daybook form must explain automatic dating");
assert.doesNotMatch(htmlSource, /id="cashDate"|id="voucherDate"/, "Daybook must not show transaction date fields");
assert.match(appSource, /data-open-cash-intake/, "Cashbook must contain the Cash Intake option");
assert.match(context.__result.renderedDaybook, /daybook-inward[\s\S]*data-open-cash-intake/, "Cash Intake option must render inside Inward");
assert.match(context.__result.renderedDaybook, /daybook-outward[\s\S]*data-open-debit-voucher/, "Debit Voucher option must render inside Outward");
assert.doesNotMatch(context.__result.renderedDaybook, /STAFF COLLECTION|Cash to receive from employees/, "Staff Collection window must not render inside Cashbook");
for (const category of ["cash-intake", "processing", "total-recovery", "closing", "advance", "later-recovery", "penalty", "disbursement", "hold-loan-deduction", "balance-recovery"]) {
  assert.match(context.__result.renderedDaybook, new RegExp(`data-daybook-category="${category}"`), `Rendered Daybook must include ${category}`);
}
const inwardOrder = ["cash-intake", "processing", "total-recovery", "closing", "advance", "later-recovery", "penalty"]
  .map((category) => context.__result.renderedDaybook.indexOf(`data-daybook-category="${category}"`));
assert.deepEqual(inwardOrder, [...inwardOrder].sort((a, b) => a - b), "Inward categories must render in the requested order");

console.log("PASS: automatic Inward/Outward posting, missed recovery clearing, updates, and duplicate protection");
