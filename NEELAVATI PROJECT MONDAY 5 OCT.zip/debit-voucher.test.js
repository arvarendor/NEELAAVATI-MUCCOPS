const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const htmlSource = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
const storage = new Map();
const formClassList = {
  values: new Set(),
  add(value) {
    this.values.add(value);
  },
  remove(value) {
    this.values.delete(value);
  },
};
const elements = new Map([
  ["#userRole", { textContent: "Cashier" }],
  ["#newDebitVoucher", { style: {} }],
  ["#currentDaybookDate", { textContent: "" }],
  ["#daybookSheets", { innerHTML: "" }],
  ["#voucherPayee", { value: "Shubham" }],
  ["#voucherDescription", { value: "Personal travel expense" }],
  ["#voucherAmount", { value: "750" }],
  ["#debitVoucherForm", { classList: formClassList, scrollIntoView() {} }],
]);

const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: {
    querySelector: (selector) => elements.get(selector) || null,
    querySelectorAll: () => [],
    createElement: () => ({ className: "", remove() {}, classList: { add() {}, remove() {} } }),
  },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  addActivity = () => {};
  toast = () => {};
  todayIso = () => "2026-08-02";
  cashEntries = [];
  currentUser = { name: "Test Cashier", loginId: "cashier-1", designation: "Cashier" };
  saveDebitVoucher();
  document.querySelector("#voucherPayee").value = "Amit";
  document.querySelector("#voucherDescription").value = "Personal purchase expense";
  document.querySelector("#voucherAmount").value = "250";
  saveDebitVoucher();
  currentUser = { name: "Test Staff", loginId: "staff-1", designation: "Staff" };
  document.querySelector("#voucherPayee").value = "Blocked";
  document.querySelector("#voucherDescription").value = "Should not save";
  document.querySelector("#voucherAmount").value = "100";
  saveDebitVoucher();
  globalThis.__result = {
    entries: JSON.parse(JSON.stringify(cashEntries)),
    stored: JSON.parse(localStorage.getItem(STORAGE.cashbook) || "[]"),
    daybookHtml: document.querySelector("#daybookSheets").innerHTML,
    currentDaybookDate: document.querySelector("#currentDaybookDate").textContent,
  };
`, context);

assert.equal(context.__result.entries.length, 2, "Unauthorized Staff must not create a debit voucher");
assert.equal(context.__result.entries[0].type, "debit", "Voucher must post as a Cashbook debit");
assert.equal(context.__result.entries[0].source, "debit-voucher", "Voucher source must be identifiable");
assert.equal("voucherNo" in context.__result.entries[0], false, "Debit Voucher must not create a voucher number");
assert.equal(context.__result.entries[0].payee, "Shubham", "Paid-to name must be retained");
assert.equal(context.__result.entries[0].expenseDescription, "Personal travel expense", "Expense details must be retained");
assert.equal(context.__result.entries[0].amount, 750, "Voucher amount must be numeric");
assert.equal(context.__result.entries[0].createdByRole, "Cashier", "Creator role must be retained");
assert.equal(context.__result.stored.length, 2, "Debit vouchers must persist in device storage");
assert.match(context.__result.daybookHtml, /Debit Voucher/, "Outward daybook must show the Debit Voucher heading");
assert.match(context.__result.daybookHtml, /Paid to Shubham/, "Outward daybook must identify the voucher payee");
assert.match(context.__result.daybookHtml, /1,000/, "Daybook Outward total must include all vouchers");
assert.match(context.__result.currentDaybookDate, /02 August 2026/, "Daybook date must be generated automatically");
assert.match(context.__result.daybookHtml, /daybook-outward[\s\S]*data-open-debit-voucher/, "Debit Voucher option must appear inside Outward");
assert.match(context.__result.daybookHtml, /daybook-inward[\s\S]*data-open-cash-intake/, "Cash Intake option must appear inside Inward");
assert.match(htmlSource, /id="debitVoucherForm"/, "Cashbook must contain the Debit Voucher form");
assert.doesNotMatch(htmlSource, /id="voucherNumber"|Voucher number/, "Debit Voucher form must not show a voucher number option");
assert.doesNotMatch(htmlSource, /id="voucherDate"|id="cashDate"/, "Daybook entry forms must not show date inputs");

console.log("PASS: number-free debit voucher, permissions, Outward posting, persistence, and UI hooks");
