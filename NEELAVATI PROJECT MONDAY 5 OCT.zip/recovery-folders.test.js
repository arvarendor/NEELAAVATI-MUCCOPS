const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const htmlSource = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
const storage = new Map();
const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: { querySelector: () => null, querySelectorAll: () => [] },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  currentUser = { name: "Director Test", loginId: "director-test", designation: "Director" };
  selectedRecoveryStaff = "all";
  groups = [{ code: "GROUP-1", name: "Test Centre", members: [
    { name: "NPA Member", uuid: "123456789012" },
    { name: "Balance Member", uuid: "234567890123" },
    { name: "Current Member", uuid: "345678901234" }
  ] }];
  loans = [{ groupCode: "GROUP-1", groupNumber: "G1", groupName: "Test Centre", staff: "Recovery Staff", day: "Monday", individualLoans: [
    { memberIndex: 0, testType: "npa", balance: 10000 },
    { memberIndex: 1, testType: "balance", balance: 8000 },
    { memberIndex: 2, testType: "current", balance: 7000 }
  ] }];
  memberDemandSnapshot = (_loan, individual) => {
    if (individual.testType === "npa") return { npa: true, overdueDays: 35, overdueDate: "2026-06-28", demand: 1200, emi: 600, penaltyBalance: 300, pendingEmiCount: 2 };
    if (individual.testType === "balance") return { npa: false, overdueDays: 4, overdueDate: "2026-07-29", demand: 800, emi: 1000, penaltyBalance: 150, pendingEmiCount: 1 };
    return { npa: false, overdueDays: 0, overdueDate: "", demand: 1000, emi: 1000, penaltyBalance: 0, pendingEmiCount: 1 };
  };
  const npaAccounts = recoveryFolderAccounts("npa");
  const balanceAccounts = recoveryFolderAccounts("balance");
  globalThis.__result = {
    npaCount: npaAccounts.length,
    npaName: npaAccounts[0]?.member?.name,
    balanceCount: balanceAccounts.length,
    balanceName: balanceAccounts[0]?.member?.name,
    balanceAmount: balanceAccounts[0]?.snapshot?.demand,
    npaRows: recoveryFolderAccountRows(npaAccounts, "npa"),
    balanceRows: recoveryFolderAccountRows(balanceAccounts, "balance")
  };
`, context);

assert.equal(context.__result.npaCount, 1, "Only 30+ day overdue customers should enter NPA folder");
assert.equal(context.__result.npaName, "NPA Member");
assert.equal(context.__result.balanceCount, 1, "Only 1-29 day overdue balances should enter Balance Recovery folder");
assert.equal(context.__result.balanceName, "Balance Member");
assert.equal(context.__result.balanceAmount, 800, "Balance Recovery folder should show the remaining recovery amount");
assert.match(context.__result.npaRows, /35 days/);
assert.match(context.__result.balanceRows, /EMI recovery demand/);
assert.match(context.__result.balanceRows, /Manual entries only before NPA/);
assert.doesNotMatch(context.__result.balanceRows, /₹50 added every overdue day/);
assert.ok(htmlSource.indexOf('id="npaFolder"') < htmlSource.indexOf('id="dayTabs"'), "NPA folder must be above weekday tabs");
assert.ok(htmlSource.indexOf('id="balanceRecoveryFolder"') < htmlSource.indexOf('id="dayTabs"'), "Balance Recovery folder must be above weekday tabs");

console.log("PASS: NPA and Balance Recovery folders, classification, details, and layout order");
