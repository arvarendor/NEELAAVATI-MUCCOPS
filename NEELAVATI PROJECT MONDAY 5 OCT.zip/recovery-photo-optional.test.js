const fs = require("fs");
const path = require("path");
const assert = require("assert");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const htmlSource = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const saveEntrySource = appSource.slice(
  appSource.indexOf("function saveRecoveryEntry()"),
  appSource.indexOf("function saveInlineRecovery")
);
const approvalSource = appSource.slice(
  appSource.indexOf("function approveRecoveryProposal"),
  appSource.indexOf("function directorEditApprovedRecovery")
);

assert.doesNotMatch(saveEntrySource, /if\s*\(!photoData\)/, "Recovery, Advance and Closing proposals must save without a photo");
assert.match(saveEntrySource, /photoData,/, "An optionally uploaded photo must still be stored with the proposal");
assert.match(approvalSource, /proposal\.type === "penalty" && !proposal\.photoData/, "Only a Penalty proposal may retain the photo requirement");
assert.doesNotMatch(approvalSource, /if\s*\(!proposal\.photoData\)/, "Recovery, Advance and Closing approval must not reject a missing photo");
assert.match(htmlSource, /Collection photo \(optional\)/, "Recovery entry form must clearly mark the photo as optional");
assert.match(appSource, /Photo upload \(optional\)/, "Inline centre recovery must mark photo upload as optional");

console.log("PASS: Recovery, Advance Recovery and Closing accept optional photos while preserving attached proof");
