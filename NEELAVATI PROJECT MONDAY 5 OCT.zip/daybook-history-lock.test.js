const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
const storage = new Map();
const elements = new Map([
  ["#newDebitVoucher", { style: {} }],
  ["#currentDaybookDate", { textContent: "" }],
  ["#daybookSheets", { innerHTML: "" }],
]);
const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: {
    querySelector: (selector) => elements.get(selector) || null,
    querySelectorAll: () => [],
    createElement: () => ({ className: "", remove() {}, classList: { add() {}, remove() {} } }),
  },
  window: {
    prompt: () => null,
    confirm: () => true,
  },
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  todayIso = () => "2026-07-09";
  groups = [{ code: "GRP-138", number: "G138", name: "Historical Centre", members: [{ name: "Asha" }] }];
  loans = [{
    id: "LOAN-138",
    groupCode: "GRP-138",
    groupNumber: "G138",
    groupName: "Historical Centre",
    amount: 12000,
    disbursedOn: "2026-07-01",
    day: "Wednesday",
    recoveryStartWeek: "custom",
    firstRecoveryDate: "2026-07-08",
    individualLoans: [{ memberIndex: 0, amount: 12000, balance: 11800, emi: 1000, term: 12, processingFee: 600, holdAmount: 2000, holdTransactions: [] }],
    recoveries: [{
      id: "REC-PARTIAL",
      type: "recovery",
      date: "2026-07-08",
      amount: 200,
      principalPaid: 200,
      penaltyPaid: 0,
      member: 0,
      allocations: [{ memberIndex: 0, amount: 200 }],
      enteredByName: "Field Staff",
    }],
  }];
  cashEntries = [];
  staffAllowances = [];
  bankHolidays = [];
  syncAutomaticCashbookEntries("2026-07-08");
  const snapshotBeforeLatePayment = JSON.parse(JSON.stringify(cashEntries));

  loans[0].recoveries.push({
    id: "REC-LATE",
    type: "recovery",
    date: "2026-07-09",
    demandDate: "2026-07-08",
    amount: 800,
    principalPaid: 800,
    penaltyPaid: 0,
    member: 0,
    allocations: [{ memberIndex: 0, amount: 800 }],
    enteredByName: "Field Staff",
  });
  syncAutomaticCashbookEntries("2026-07-09");
  syncAutomaticCashbookEntries("2026-07-09");
  const afterLatePayment = JSON.parse(JSON.stringify(cashEntries));

  currentUser = { name: "Shubham", loginId: "shubham", designation: "Director" };
  renderCashbook();
  const directorDaybook = document.querySelector("#daybookSheets").innerHTML;
  const promptAnswers = ["750", "Verified cash-count correction"];
  window.prompt = () => promptAnswers.shift();
  window.confirm = () => true;
  toast = (message) => { globalThis.__lastToast = message; };
  addActivity = () => {};
  const missedEntry = cashEntries.find((entry) => entry.source === "missed-recovery" && entry.date === "2026-07-08");
  directorEditDaybookEntry(missedEntry.id);
  syncAutomaticCashbookEntries("2026-07-09");
  const afterDirectorCorrection = JSON.parse(JSON.stringify(cashEntries));

  currentUser = { name: "Manager", loginId: "manager", designation: "Manager" };
  directorEditDaybookEntry(missedEntry.id);
  renderCashbook();
  const managerDaybook = document.querySelector("#daybookSheets").innerHTML;
  globalThis.__result = {
    snapshotBeforeLatePayment,
    afterLatePayment,
    afterDirectorCorrection,
    afterManagerAttempt: JSON.parse(JSON.stringify(cashEntries)),
    directorDaybook,
    managerDaybook,
  };
`, context);

const missedBefore = context.__result.snapshotBeforeLatePayment.filter((entry) => entry.source === "missed-recovery");
assert.equal(missedBefore.length, 1, "The unpaid part must be captured in the due-date Daybook");
assert.equal(missedBefore[0].date, "2026-07-08", "Balance Recovery must stay on the original due date");
assert.equal(missedBefore[0].amount, 800, "The due-date snapshot must contain only the unpaid balance");
assert.equal(missedBefore[0].historicalSnapshot, true, "Balance Recovery must be marked as a historical snapshot");

const missedAfter = context.__result.afterLatePayment.filter((entry) => entry.source === "missed-recovery");
assert.equal(missedAfter.length, 1, "Next-day payment must not delete the previous day's Balance Recovery");
assert.equal(missedAfter[0].date, "2026-07-08", "The previous Balance Recovery date must remain unchanged");
assert.equal(missedAfter[0].amount, 800, "The previous day's amount must remain a permanent snapshot");
const lateEntries = context.__result.afterLatePayment.filter((entry) => entry.source === "recovery" && entry.daybookCategory === "later-recovery");
assert.equal(lateEntries.length, 1, "The next-day payment must create exactly one Late Recovery entry");
assert.equal(lateEntries[0].date, "2026-07-09", "Late Recovery must post in the payment-day Daybook");
assert.equal(lateEntries[0].amount, 800, "Late Recovery must show the received amount separately");
assert.equal(new Set(context.__result.afterLatePayment.map((entry) => entry.autoKey).filter(Boolean)).size, context.__result.afterLatePayment.filter((entry) => entry.autoKey).length, "Repeated synchronization must not duplicate automatic entries");

const corrected = context.__result.afterDirectorCorrection.find((entry) => entry.source === "missed-recovery");
assert.equal(corrected.amount, 750, "Director must be able to correct a past Daybook amount");
assert.equal(corrected.originalAmount, 800, "Director correction must preserve the original amount for audit");
assert.equal(corrected.correctionNote, "Verified cash-count correction", "Director correction must retain its audit note");
assert.equal(corrected.directorOverride, true, "Director correction must be protected from automatic synchronization");
assert.equal(context.__result.afterManagerAttempt.find((entry) => entry.id === corrected.id).amount, 750, "Manager must not edit a closed past Daybook");
assert.match(context.__result.directorDaybook, /Past day · Director correction enabled/, "Director must see the past-day correction status");
assert.match(context.__result.directorDaybook, /data-edit-daybook-entry=/, "Director must see an Edit action on eligible past entries");
assert.match(context.__result.managerDaybook, /Past day locked/, "Non-Director logins must see past Daybooks as locked");
assert.doesNotMatch(context.__result.managerDaybook, /data-edit-daybook-entry=/, "Non-Director logins must not receive a past Daybook edit action");

console.log("PASS: permanent Balance Recovery snapshots, next-day Late Recovery, and Director-only past Daybook correction");
