const fs = require("fs");
const path = require("path");
const assert = require("assert");

const htmlSource = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const cssSource = fs.readFileSync(path.join(__dirname, "style.css"), "utf8");

const template = htmlSource.slice(
  htmlSource.indexOf('<template id="memberTemplate">'),
  htmlSource.indexOf('</template>', htmlSource.indexOf('<template id="memberTemplate">'))
);
const photoIndex = template.indexOf('class="verification-photo-first"');
const detailsIndex = template.indexOf('class="form-grid"');
const optionsIndex = template.indexOf('class="verify-options"');

assert.ok(photoIndex > -1, "Verification must contain a top customer-photo panel");
assert.ok(photoIndex < detailsIndex, "Customer photo must appear before all customer detail fields");
assert.ok(detailsIndex < optionsIndex, "Verification options must remain after customer details");
assert.match(template, /class="m-photo"[^>]*capture="environment"/, "Photo control must support camera capture");
assert.equal((template.match(/class="m-photo"/g) || []).length, 1, "Each customer must have one photo control");
assert.match(appSource, /function renderVerificationPhoto\(member\)/, "Verification must render the saved or selected photo");
assert.match(appSource, /member\.dataset\.photoData = await compressPhoto\(file\);\s*renderVerificationPhoto\(member\);/, "Photo preview must update immediately after upload");
assert.match(cssSource, /\.verification-photo-preview img\{[^}]*object-fit:cover/, "Customer photo preview must be visibly framed at the top");

console.log("PASS: Verification photo is first, visible, camera-ready, and updates immediately");
