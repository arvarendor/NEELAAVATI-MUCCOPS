const fs = require("fs");
const assert = require("assert");
const path = require("path");

const html = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const app = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const server = fs.readFileSync(path.join(__dirname, "server", "server.mjs"), "utf8");
const database = fs.readFileSync(path.join(__dirname, "server", "database.mjs"), "utf8");

assert.match(html, /data-page="working"[^>]*>[\s\S]*?<span>My Working<\/span>/, "Incentive must be renamed My Working in core navigation");
assert.match(html, /id="myWorkingContent"/, "My Working must have one role-aware content host");
assert.doesNotMatch(app, /Director: \[[^\]]*"working"/, "Director must not have a standalone My Working core feature");
assert.match(app, /employeeWorkingTab[\s\S]*employeeAttendanceTab/, "Director Employee Management must include My Working and Staff Attendance options");
assert.match(app, /Cashier: \[[^\]]*"working"/, "Cashier needs My Working access to update attendance");
assert.match(app, /Executive: \[[^\]]*"working"/, "Executive needs My Working access to view live salary");
assert.match(app, /ATTENDANCE_SALARY_ROLES = \["Manager", "Assistant Manager", "Cashier", "Executive", "Staff"\]/, "Cashier and Executive must follow the same attendance salary rules");
assert.match(app, /if \(role\(\) !== "Cashier"\)[\s\S]*Only the Cashier can update attendance/, "Attendance updates must be Cashier-only");
assert.match(app, /if \(role\(\) !== "Director"\)[\s\S]*Only the Director can give a performance star rating/, "Performance ratings must be Director-only");
assert.match(app, /Math\.floor\(counts\["Half Day"\] \/ 2\) \+ Math\.floor\(counts\.Late \/ 3\)/, "Every two half days and every three late marks must deduct one day");
assert.match(app, /const daily = monthly \/ 30/, "Salary and allowances must accrue at monthly amount divided by 30");
assert.match(app, /ownAccount\?\.designation === "Cashier"[\s\S]*renderEmployeeWorking\(ownSalary, ownAccount\)/, "Cashier must see personal live salary below the attendance register");
assert.match(app, /\["Staff", "Manager", "Assistant Manager", "Executive"\]\.includes\(role\(\)\)/, "Executive must see a personal My Working dashboard");
assert.match(app, /PERFORMANCE_RATING_ROLES = \["Staff"\]/, "Only Staff may receive Director star ratings");
assert.match(app, /ASSISTANT_PERFORMANCE_FILE_TARGET = 12[\s\S]*ASSISTANT_PERFORMANCE_PER_QUALIFIED_STAFF = 2000/, "Assistant Manager performance must be automatic per Staff completing 12 files");
assert.match(app, /Recovery allowance/, "Petrol allowance must be presented as Recovery allowance");
assert.match(app, /workingRecords/, "Attendance and rating records must be persisted");
assert.match(app, /function renderAttendanceCalendar\(statement\)/, "Attendance history must render as a monthly calendar");
assert.match(app, /status-present[\s\S]*status-absent[\s\S]*status-half-day[\s\S]*status-late/, "Each attendance status must have a separate calendar state");
assert.match(app, /changeWorkingCalendarMonth\(-1\)[\s\S]*changeWorkingCalendarMonth\(1\)/, "Attendance calendar must support previous and next month history");
assert.match(html, /working-calendar-day\.status-present[\s\S]*working-calendar-day\.status-absent[\s\S]*working-calendar-day\.status-half-day[\s\S]*working-calendar-day\.status-late/, "Present, Absent, Half Day and Late must use different calendar colors");
assert.match(database, /Cashier: new Set\(\[[^\]]*"workingRecords"/, "Secure backend must allow the Cashier to update attendance records");
assert.match(database, /employeeWorkingProfile\(userId\)[\s\S]*"Cashier", "Executive"/, "Secure backend must return private live salary profiles for Cashier and Executive");
assert.match(server, /workingProfile: store\.employeeWorkingProfile\(session\.user\.id\)/, "Secure backend must return only the signed-in employee's private working profile");
assert.match(server, /teamWorkingProfiles: store\.assistantManagerTeamWorkingProfiles\(session\.user\.id\)/, "Secure backend must return the Assistant Manager's assigned Staff working profiles");
assert.match(database, /function assistantManagerTeamWorkingProfiles\(userId\)[\s\S]*assistant\.role !== "Assistant Manager"[\s\S]*u\.assistant_manager_user_id = \?/, "Team working compensation must be scoped to the signed-in Assistant Manager");
assert.match(app, /role\(\) === "Assistant Manager"[\s\S]*assistantManagerTeamWorkingMarkup\(account\)/, "Assistant Manager My Working must include assigned Staff working details");

const salary = 15000;
const daily = salary / 30;
const halfDays = 2;
const lates = 3;
const creditedDays = 10;
const payableDays = creditedDays - Math.floor(halfDays / 2) - Math.floor(lates / 3);
assert.equal(daily, 500, "₹15,000 monthly basic salary must accrue at ₹500 per day");
assert.equal(payableDays, 8, "Two half days and three late marks must deduct two full days");
assert.equal(3 * 2000, 6000, "Three qualifying Staff must pay ₹6,000 Assistant Manager performance allowance");
assert.equal(5 * 1000, 5000, "Five Staff stars must pay ₹5,000");

console.log("PASS: My Working applies secure attendance, daily accrual and Director star performance rules");
