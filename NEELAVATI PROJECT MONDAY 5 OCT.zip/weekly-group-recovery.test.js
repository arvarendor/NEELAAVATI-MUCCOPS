const fs = require("fs");
const path = require("path");
const assert = require("assert");

const source = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const start = source.indexOf("function recoveryUpdateTimestamp");
const end = source.indexOf("function groupScheduleHtml", start);
assert.ok(start >= 0 && end > start, "Weekly Group Recovery helpers must be present");

const helperSource = source.slice(start, end);
const createHelpers = new Function(
  "scheduleRows",
  "loanRecoveryStartMode",
  `${helperSource}; return { recoveryUpdateTime, groupScheduleRecoveryRows };`
);
const scheduleRows = () => [
  { type: "installment", number: 1, date: "2026-08-24" },
  { type: "installment", number: 2, date: "2026-08-31" },
];
const { groupScheduleRecoveryRows } = createHelpers(scheduleRows, () => "next");

const rows = groupScheduleRecoveryRows({
  term: 2,
  disbursedOn: "2026-08-17",
  day: "Monday",
  emi: 3000,
  recoveries: [
    { type: "recovery", demandDate: "2026-08-24", amount: 600, enteredAt: "2026-08-24T10:30:00", attendance: "1", review: "First EMI" },
    { type: "recovery", demandDate: "2026-08-24", amount: 700, enteredAt: "2026-08-24T10:35:00", attendance: "1", review: "Second EMI" },
    { type: "advance", demandDate: "2026-08-24", amount: 1400, enteredAt: "2026-08-24T10:45:00", attendance: "1", review: "Advance recovery" },
    { type: "closing", demandDate: "2026-08-31", amount: 5000, enteredAt: "2026-08-31T09:15:00", attendance: "1", review: "Loan closed" },
  ],
});

assert.equal(rows[0].groupEmi, 3000, "Scheduled Group EMI must stay visible");
assert.equal(rows[0].emi, 1300, "Normal member recoveries must total in the EMI column");
assert.equal(rows[0].advance, 1400, "Advance member recoveries must total separately");
assert.equal(rows[0].closing, 0, "Closing must not be mixed into EMI or Advance");
assert.match(rows[0].updateTime, /10:45\s*am/i, "Latest automatic staff update time must be shown");
assert.equal(rows[1].closing, 5000, "Closing recoveries must total in the Closing column");
assert.equal(rows[1].updateTime.match(/09:15/i)?.[0], "09:15", "Closing row must retain its automatic update time");
assert.doesNotMatch(helperSource, /\.receipt|\.timeIn|\.timeOut/, "Weekly totals must not depend on receipt or manual time fields");

console.log("PASS: Weekly Group Recovery aggregates EMI, Advance and Closing with automatic update time");
