import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";
import { createApplicationServer } from "./server.mjs";

function cookieFrom(response) {
  return String(response.headers.get("set-cookie") || "").split(";")[0];
}

async function jsonRequest(base, route, options = {}) {
  const response = await fetch(`${base}${route}`, {
    method: options.method || "GET",
    headers: {
      ...(options.body !== undefined ? { "Content-Type": "application/json" } : {}),
      ...(options.cookie ? { Cookie: options.cookie } : {}),
      ...(options.csrf ? { "X-CSRF-Token": options.csrf } : {}),
    },
    body: options.body === undefined ? undefined : JSON.stringify(options.body),
  });
  const payload = await response.json();
  return { response, payload };
}

test("secure authentication, encrypted state, CSRF, roles, and audit-ready users", async (t) => {
  const dataDirectory = await mkdtemp(path.join(os.tmpdir(), "neelavati-backend-"));
  const { server } = await createApplicationServer({
    dataDirectory,
    encryptionKey: Buffer.alloc(32, 7).toString("base64"),
    passwordPepper: "test-only-pepper",
    initialDirectorPassword: "Strong@1234",
    production: false,
  });
  await new Promise((resolve) => server.listen(0, "127.0.0.1", resolve));
  const address = server.address();
  const base = `http://127.0.0.1:${address.port}`;
  t.after(async () => {
    await new Promise((resolve) => server.close(resolve));
    await rm(dataDirectory, { recursive: true, force: true });
  });

  const health = await jsonRequest(base, "/api/health");
  assert.equal(health.response.status, 200);
  assert.equal(health.payload.service, "neelavati-secure-backend");

  const denied = await jsonRequest(base, "/api/auth/login", { method: "POST", body: { loginId: "shubham", password: "wrong" } });
  assert.equal(denied.response.status, 401);

  const directorLogin = await jsonRequest(base, "/api/auth/login", {
    method: "POST",
    body: { loginId: "shubham", password: "Strong@1234" },
  });
  assert.equal(directorLogin.response.status, 200);
  assert.equal(directorLogin.payload.user.designation, "Director");
  const directorCookie = cookieFrom(directorLogin.response);
  const directorCsrf = directorLogin.payload.csrfToken;
  assert.match(directorCookie, /^nmc_session=/);

  const initialState = await jsonRequest(base, "/api/state", { cookie: directorCookie });
  assert.equal(initialState.response.status, 200);
  assert.equal(initialState.payload.version, 0);
  assert.deepEqual(initialState.payload.data.groups, []);

  const csrfRejected = await jsonRequest(base, "/api/state", {
    method: "PUT",
    cookie: directorCookie,
    body: { data: initialState.payload.data, baseVersion: 0 },
  });
  assert.equal(csrfRejected.response.status, 403);
  assert.equal(csrfRejected.payload.error, "csrf_rejected");

  const groupState = { ...initialState.payload.data, groups: [{ id: "group-1", code: "group-1", number: "G1", name: "Test Centre", recoveryStaff: "Recovery Staff" }] };
  const stateSaved = await jsonRequest(base, "/api/state", {
    method: "PUT",
    cookie: directorCookie,
    csrf: directorCsrf,
    body: { data: groupState, baseVersion: 0 },
  });
  assert.equal(stateSaved.response.status, 200);
  assert.equal(stateSaved.payload.version, 1);

  const managerCreated = await jsonRequest(base, "/api/users", {
    method: "POST",
    cookie: directorCookie,
    csrf: directorCsrf,
    body: {
      name: "Branch Manager", loginId: "manager-001", password: "Manager@12345", designation: "Manager",
      salary: 30000, performanceAllowance: 2500, petrolAllowance: 2200, businessAllowance: 1800, incentive: 1500, recurringDeposit: 1200,
    },
  });
  assert.equal(managerCreated.response.status, 201);
  assert.equal(managerCreated.payload.user.salary, 30000);
  assert.equal(managerCreated.payload.user.performanceAllowance, 0);
  assert.equal(managerCreated.payload.user.petrolAllowance, 0);
  assert.equal(managerCreated.payload.user.businessAllowance, 0);
  assert.equal(managerCreated.payload.user.incentive, 1500);
  assert.equal(managerCreated.payload.user.recurringDeposit, 1200);
  assert.equal(managerCreated.payload.user.recurringDepositStartedAt, new Date().toISOString().slice(0, 7));

  const assistantCreated = await jsonRequest(base, "/api/users", {
    method: "POST",
    cookie: directorCookie,
    csrf: directorCsrf,
    body: {
      name: "Assistant Manager", loginId: "assistant-001", password: "Assistant@12345", designation: "Assistant Manager",
      salary: 24000, performanceAllowance: 1700, petrolAllowance: 1500, businessAllowance: 1100, incentive: 900, recurringDeposit: 1000,
    },
  });
  assert.equal(assistantCreated.response.status, 201);
  assert.equal(assistantCreated.payload.user.petrolAllowance, 0);
  assert.equal(assistantCreated.payload.user.businessAllowance, 0);
  assert.equal(assistantCreated.payload.user.performanceAllowance, 0);
  assert.equal(assistantCreated.payload.user.incentive, 900);

  const cashierCreated = await jsonRequest(base, "/api/users", {
    method: "POST",
    cookie: directorCookie,
    csrf: directorCsrf,
    body: {
      name: "Cashier", loginId: "cashier-001", password: "Cashier@12345", designation: "Cashier",
      salary: 21000, performanceAllowance: 9999,
    },
  });
  assert.equal(cashierCreated.response.status, 201);
  assert.equal(cashierCreated.payload.user.salary, 21000);
  assert.equal(cashierCreated.payload.user.performanceAllowance, 0);

  const staffCreated = await jsonRequest(base, "/api/users", {
    method: "POST",
    cookie: directorCookie,
    csrf: directorCsrf,
    body: {
      name: "Recovery Staff", loginId: "staff-001", password: "Staff@12345", designation: "Staff",
      managerLoginId: "manager-001", assistantManagerLoginId: "assistant-001",
      salary: 18000, performanceAllowance: 1500,
      petrolAllowance: 2000, businessAllowance: 750, incentive: 40, recurringDeposit: 500,
    },
  });
  assert.equal(staffCreated.response.status, 201);
  assert.equal(staffCreated.payload.user.designation, "Staff");
  assert.equal(staffCreated.payload.user.managerName, "Branch Manager");
  assert.equal(staffCreated.payload.user.managerLoginId, "manager-001");
  assert.equal(staffCreated.payload.user.assistantManagerName, "Assistant Manager");
  assert.equal(staffCreated.payload.user.assistantManagerLoginId, "assistant-001");
  assert.equal(staffCreated.payload.user.salary, 18000);
  assert.equal(staffCreated.payload.user.performanceAllowance, 1500);
  assert.equal(staffCreated.payload.user.petrolAllowance, 2000);
  assert.equal(staffCreated.payload.user.businessAllowance, 750);
  assert.equal(staffCreated.payload.user.incentive, 40);
  assert.equal(staffCreated.payload.user.recurringDeposit, 500);
  assert.equal(staffCreated.payload.user.recurringDepositStartedAt, new Date().toISOString().slice(0, 7));
  assert.equal("password" in staffCreated.payload.user, false);

  const unassignedStaffCreated = await jsonRequest(base, "/api/users", {
    method: "POST",
    cookie: directorCookie,
    csrf: directorCsrf,
    body: {
      name: "Unassigned Staff", loginId: "staff-unassigned", password: "Unassigned@12345", designation: "Staff",
      salary: 16000, petrolAllowance: 1200, businessAllowance: 500, incentive: 35,
    },
  });
  assert.equal(unassignedStaffCreated.response.status, 201);
  assert.equal(unassignedStaffCreated.payload.user.managerLoginId, "");
  assert.equal(unassignedStaffCreated.payload.user.assistantManagerLoginId, "");

  const invalidOptionalAssignment = await jsonRequest(base, "/api/users", {
    method: "POST",
    cookie: directorCookie,
    csrf: directorCsrf,
    body: {
      name: "Invalid Assignment", loginId: "staff-invalid-assignment", password: "InvalidAssign@12345", designation: "Staff",
      managerLoginId: "missing-manager", salary: 16000,
    },
  });
  assert.equal(invalidOptionalAssignment.response.status, 400);
  assert.equal(invalidOptionalAssignment.payload.error, "invalid_manager");

  const secondAssistantCreated = await jsonRequest(base, "/api/users", {
    method: "POST",
    cookie: directorCookie,
    csrf: directorCsrf,
    body: {
      name: "Second Assistant", loginId: "assistant-002", password: "Assistant2@12345", designation: "Assistant Manager",
      salary: 23000, incentive: 25,
    },
  });
  assert.equal(secondAssistantCreated.response.status, 201);

  const staffReassigned = await jsonRequest(base, `/api/users/${staffCreated.payload.user.id}/assistant-manager`, {
    method: "PATCH",
    cookie: directorCookie,
    csrf: directorCsrf,
    body: { assistantManagerLoginId: "assistant-002" },
  });
  assert.equal(staffReassigned.response.status, 200);

  const assistantIncentiveUpdated = await jsonRequest(base, `/api/users/${assistantCreated.payload.user.id}/team-incentive`, {
    method: "PATCH",
    cookie: directorCookie,
    csrf: directorCsrf,
    body: { incentive: 27 },
  });
  assert.equal(assistantIncentiveUpdated.response.status, 200);

  const recurringDepositUpdated = await jsonRequest(base, `/api/users/${staffCreated.payload.user.id}/recurring-deposit`, {
    method: "PATCH",
    cookie: directorCookie,
    csrf: directorCsrf,
    body: { recurringDeposit: 700 },
  });
  assert.equal(recurringDepositUpdated.response.status, 200);

  const directorSalaryState = await jsonRequest(base, "/api/state", { cookie: directorCookie });
  const directorStaffRecord = directorSalaryState.payload.employees.find((employee) => employee.loginId === "staff-001");
  assert.equal(directorStaffRecord.salary, 18000);
  assert.equal(directorStaffRecord.assistantManagerLoginId, "assistant-002");
  assert.equal(directorStaffRecord.assistantManagerName, "Second Assistant");
  assert.equal(directorStaffRecord.recurringDeposit, 700);
  assert.equal(directorStaffRecord.recurringDepositStartedAt, staffCreated.payload.user.recurringDepositStartedAt);

  const managerLogin = await jsonRequest(base, "/api/auth/login", {
    method: "POST",
    body: { loginId: "manager-001", password: "Manager@12345" },
  });
  assert.equal(managerLogin.response.status, 200);
  const managerState = await jsonRequest(base, "/api/state", { cookie: cookieFrom(managerLogin.response) });
  const managerStaffRecord = managerState.payload.employees.find((employee) => employee.loginId === "staff-001");
  assert.equal("salary" in managerStaffRecord, false);
  assert.equal("performanceAllowance" in managerStaffRecord, false);
  assert.deepEqual(managerState.payload.incentiveProfile, { loginId: "manager-001", incentive: 1500 });
  assert.deepEqual(managerState.payload.workingProfile, {
    loginId: "manager-001", salary: 30000, recoveryAllowance: 0, businessAllowance: 0, incentive: 1500, recurringDeposit: 1200,
    recurringDepositStartedAt: managerCreated.payload.user.recurringDepositStartedAt,
  });

  const assistantLogin = await jsonRequest(base, "/api/auth/login", {
    method: "POST",
    body: { loginId: "assistant-001", password: "Assistant@12345" },
  });
  assert.equal(assistantLogin.response.status, 200);
  const assistantState = await jsonRequest(base, "/api/state", { cookie: cookieFrom(assistantLogin.response) });
  assert.deepEqual(assistantState.payload.incentiveProfile, { loginId: "assistant-001", incentive: 27 });
  assert.deepEqual(assistantState.payload.workingProfile, {
    loginId: "assistant-001", salary: 24000, recoveryAllowance: 0, businessAllowance: 0, incentive: 27, recurringDeposit: 1000,
    recurringDepositStartedAt: assistantCreated.payload.user.recurringDepositStartedAt,
  });
  assert.deepEqual(assistantState.payload.teamWorkingProfiles, []);

  const secondAssistantLogin = await jsonRequest(base, "/api/auth/login", {
    method: "POST",
    body: { loginId: "assistant-002", password: "Assistant2@12345" },
  });
  assert.equal(secondAssistantLogin.response.status, 200);
  const secondAssistantCookie = cookieFrom(secondAssistantLogin.response);
  const secondAssistantCsrf = secondAssistantLogin.payload.csrfToken;
  const secondAssistantState = await jsonRequest(base, "/api/state", { cookie: secondAssistantCookie });
  assert.deepEqual(secondAssistantState.payload.teamWorkingProfiles.map((employee) => employee.loginId), ["staff-001"]);
  assert.equal(secondAssistantState.payload.teamWorkingProfiles[0].salary, 18000);
  assert.equal(secondAssistantState.payload.teamWorkingProfiles[0].petrolAllowance, 2000);
  assert.equal(secondAssistantState.payload.teamWorkingProfiles[0].businessAllowance, 750);
  assert.equal(secondAssistantState.payload.teamWorkingProfiles[0].incentive, 40);
  assert.equal(secondAssistantState.payload.teamWorkingProfiles[0].recurringDeposit, 700);

  const staffLogin = await jsonRequest(base, "/api/auth/login", {
    method: "POST",
    body: { loginId: "staff-001", password: "Staff@12345" },
  });
  assert.equal(staffLogin.response.status, 200);
  const staffCookie = cookieFrom(staffLogin.response);
  const staffCsrf = staffLogin.payload.csrfToken;

  const forbiddenUserCreate = await jsonRequest(base, "/api/users", {
    method: "POST",
    cookie: staffCookie,
    csrf: staffCsrf,
    body: { name: "No Access", loginId: "no-access", password: "Blocked@123", designation: "Staff" },
  });
  assert.equal(forbiddenUserCreate.response.status, 403);

  const staffState = await jsonRequest(base, "/api/state", { cookie: staffCookie });
  assert.deepEqual(staffState.payload.incentiveProfile, { loginId: "staff-001", incentive: 40 });
  assert.deepEqual(staffState.payload.workingProfile, {
    loginId: "staff-001", salary: 18000, recoveryAllowance: 2000, businessAllowance: 750, incentive: 40, recurringDeposit: 700,
    recurringDepositStartedAt: staffCreated.payload.user.recurringDepositStartedAt,
  });
  const staffOwnRecord = staffState.payload.employees.find((employee) => employee.loginId === "staff-001");
  assert.equal("incentive" in staffOwnRecord, false);
  const forbiddenGroupChange = await jsonRequest(base, "/api/state", {
    method: "PUT",
    cookie: staffCookie,
    csrf: staffCsrf,
    body: { data: { ...staffState.payload.data, groups: [] }, baseVersion: staffState.payload.version },
  });
  assert.equal(forbiddenGroupChange.response.status, 403);
  assert.equal(forbiddenGroupChange.payload.error, "forbidden_state_change");

  const allowedLoanChange = await jsonRequest(base, "/api/state", {
    method: "PUT",
    cookie: staffCookie,
    csrf: staffCsrf,
    body: {
      data: {
        ...staffState.payload.data,
        loans: [{
          id: "loan-1", groupCode: "group-1", groupNumber: "G1", groupName: "Test Centre",
          staff: "Recovery Staff", recoveryStaffLoginId: "staff-001",
          recoveryAssistantManagerLoginId: "assistant-001", proposals: [],
        }],
      },
      baseVersion: staffState.payload.version,
    },
  });
  assert.equal(allowedLoanChange.response.status, 200);
  assert.equal(allowedLoanChange.payload.version, 2);

  const forbiddenStaffReassignment = await jsonRequest(base, "/api/loans/loan-1/recovery-staff", {
    method: "PATCH",
    cookie: staffCookie,
    csrf: staffCsrf,
    body: { staffLoginId: "staff-unassigned" },
  });
  assert.equal(forbiddenStaffReassignment.response.status, 403);

  const assistantReassignment = await jsonRequest(base, "/api/loans/loan-1/recovery-staff", {
    method: "PATCH",
    cookie: secondAssistantCookie,
    csrf: secondAssistantCsrf,
    body: { staffLoginId: "staff-unassigned" },
  });
  assert.equal(assistantReassignment.response.status, 200);
  assert.equal(assistantReassignment.payload.version, 3);
  assert.equal(assistantReassignment.payload.loan.staff, "Unassigned Staff");
  assert.equal(assistantReassignment.payload.group.recoveryStaff, "Unassigned Staff");

  const cashierLogin = await jsonRequest(base, "/api/auth/login", {
    method: "POST",
    body: { loginId: "cashier-001", password: "Cashier@12345" },
  });
  assert.equal(cashierLogin.response.status, 200);
  const cashierCookie = cookieFrom(cashierLogin.response);
  const cashierCsrf = cashierLogin.payload.csrfToken;
  const cashierReassignment = await jsonRequest(base, "/api/loans/loan-1/recovery-staff", {
    method: "PATCH",
    cookie: cashierCookie,
    csrf: cashierCsrf,
    body: { staffLoginId: "staff-001" },
  });
  assert.equal(cashierReassignment.response.status, 200);
  assert.equal(cashierReassignment.payload.version, 4);
  assert.equal(cashierReassignment.payload.loan.staff, "Recovery Staff");
  assert.equal(cashierReassignment.payload.loan.staffAssignmentHistory.length, 2);
  const cashierState = await jsonRequest(base, "/api/state", { cookie: cashierCookie });
  assert.deepEqual(cashierState.payload.workingProfile, {
    loginId: "cashier-001", salary: 21000, recoveryAllowance: 0, businessAllowance: 0, incentive: 0, recurringDeposit: 0,
    recurringDepositStartedAt: "",
  });
  const attendanceSaved = await jsonRequest(base, "/api/state", {
    method: "PUT",
    cookie: cashierCookie,
    csrf: cashierCsrf,
    body: {
      data: {
        ...cashierState.payload.data,
        workingRecords: [{ kind: "attendance", employeeLoginId: "staff-001", date: "2026-10-03", status: "Present" }],
      },
      baseVersion: cashierState.payload.version,
    },
  });
  assert.equal(attendanceSaved.response.status, 200);
  assert.equal(attendanceSaved.payload.version, 5);
});
