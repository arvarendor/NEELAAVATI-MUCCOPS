import { createCipheriv, createDecipheriv, createHash, randomBytes, scrypt as scryptCallback, timingSafeEqual } from "node:crypto";
import { chmod, mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { promisify } from "node:util";

const scrypt = promisify(scryptCallback);

export function normalizeLogin(value) {
  return String(value || "").trim().toLowerCase();
}

export function validatePassword(password) {
  const value = String(password || "");
  if (value.length < 10) return "Password must contain at least 10 characters.";
  if (!/[a-z]/.test(value) || !/[A-Z]/.test(value) || !/\d/.test(value) || !/[^A-Za-z0-9]/.test(value)) {
    return "Password must include upper-case, lower-case, number, and symbol.";
  }
  return "";
}

export async function hashPassword(password, pepper = "") {
  const salt = randomBytes(16);
  const derived = await scrypt(`${password}${pepper}`, salt, 64, { N: 16384, r: 8, p: 1 });
  return { salt: salt.toString("base64"), hash: Buffer.from(derived).toString("base64") };
}

export async function verifyPassword(password, saltBase64, hashBase64, pepper = "") {
  const salt = Buffer.from(saltBase64, "base64");
  const expected = Buffer.from(hashBase64, "base64");
  const actual = Buffer.from(await scrypt(`${password}${pepper}`, salt, expected.length, { N: 16384, r: 8, p: 1 }));
  return expected.length === actual.length && timingSafeEqual(expected, actual);
}

export function randomToken(bytes = 32) {
  return randomBytes(bytes).toString("base64url");
}

export function tokenHash(token) {
  return createHash("sha256").update(String(token || "")).digest("hex");
}

function parseMasterKey(value) {
  const raw = String(value || "").trim();
  if (!raw) return null;
  const buffer = /^[a-f0-9]{64}$/i.test(raw) ? Buffer.from(raw, "hex") : Buffer.from(raw, "base64");
  if (buffer.length !== 32) throw new Error("DATA_ENCRYPTION_KEY must decode to exactly 32 bytes.");
  return buffer;
}

export async function loadMasterKey(dataDirectory, suppliedKey, production = false) {
  const fromEnvironment = parseMasterKey(suppliedKey);
  if (fromEnvironment) return fromEnvironment;
  if (production) throw new Error("DATA_ENCRYPTION_KEY is required in production.");

  await mkdir(dataDirectory, { recursive: true });
  const keyPath = path.join(dataDirectory, ".master-key");
  try {
    return parseMasterKey(await readFile(keyPath, "utf8"));
  } catch (error) {
    if (error?.code !== "ENOENT") throw error;
  }
  const generated = randomBytes(32);
  await writeFile(keyPath, `${generated.toString("base64")}\n`, { encoding: "utf8", flag: "wx", mode: 0o600 });
  try { await chmod(keyPath, 0o600); } catch { /* Windows may not apply POSIX modes. */ }
  return generated;
}

export function encryptJson(value, key) {
  const iv = randomBytes(12);
  const cipher = createCipheriv("aes-256-gcm", key, iv);
  const ciphertext = Buffer.concat([cipher.update(JSON.stringify(value), "utf8"), cipher.final()]);
  return {
    ciphertext: ciphertext.toString("base64"),
    iv: iv.toString("base64"),
    tag: cipher.getAuthTag().toString("base64"),
  };
}

export function decryptJson(record, key) {
  const decipher = createDecipheriv("aes-256-gcm", key, Buffer.from(record.iv, "base64"));
  decipher.setAuthTag(Buffer.from(record.tag, "base64"));
  const plaintext = Buffer.concat([
    decipher.update(Buffer.from(record.ciphertext, "base64")),
    decipher.final(),
  ]).toString("utf8");
  return JSON.parse(plaintext);
}

export function safeEqualText(left, right) {
  const a = Buffer.from(String(left || ""));
  const b = Buffer.from(String(right || ""));
  return a.length === b.length && timingSafeEqual(a, b);
}
