import { createServer as createHttpServer } from "node:http";
import { readFile, stat } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { openStore } from "./database.mjs";
import { safeEqualText } from "./security.mjs";

const MODULE_DIRECTORY = path.dirname(fileURLToPath(import.meta.url));
const PROJECT_DIRECTORY = path.resolve(MODULE_DIRECTORY, "..");
const DEFAULT_STATIC_DIRECTORY = path.join(PROJECT_DIRECTORY, "dist");
const SESSION_COOKIE = "nmc_session";
const MAX_JSON_BYTES = 25 * 1024 * 1024;
const LOGIN_WINDOW_MS = 15 * 60 * 1000;
const LOGIN_LIMIT = 5;

const CONTENT_TYPES = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".svg": "image/svg+xml",
  ".json": "application/json; charset=utf-8",
};

function parseCookies(header = "") {
  return Object.fromEntries(String(header).split(";").map((part) => part.trim()).filter(Boolean).map((part) => {
    const separator = part.indexOf("=");
    return separator < 0 ? [part, ""] : [part.slice(0, separator), decodeURIComponent(part.slice(separator + 1))];
  }));
}

function json(response, status, payload, headers = {}) {
  const body = JSON.stringify(payload);
  response.writeHead(status, { "Content-Type": "application/json; charset=utf-8", "Content-Length": Buffer.byteLength(body), ...headers });
  response.end(body);
}

function securityHeaders(request, response, production) {
  response.setHeader("X-Content-Type-Options", "nosniff");
  response.setHeader("X-Frame-Options", "DENY");
  response.setHeader("Referrer-Policy", "no-referrer");
  response.setHeader("Permissions-Policy", "camera=(self), geolocation=(self), microphone=()");
  response.setHeader("Content-Security-Policy", "default-src 'self'; img-src 'self' data: blob:; style-src 'self'; script-src 'self'; connect-src 'self'; object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'");
  if (production || request.headers["x-forwarded-proto"] === "https") response.setHeader("Strict-Transport-Security", "max-age=31536000; includeSubDomains");
}

async function readJsonBody(request) {
  const contentType = String(request.headers["content-type"] || "").split(";")[0].trim();
  if (contentType !== "application/json") {
    const error = new Error("Content-Type must be application/json.");
    error.status = 415;
    error.code = "unsupported_media_type";
    throw error;
  }
  let size = 0;
  const chunks = [];
  for await (const chunk of request) {
    size += chunk.length;
    if (size > MAX_JSON_BYTES) {
      const error = new Error("Request is too large.");
      error.status = 413;
      error.code = "payload_too_large";
      throw error;
    }
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString("utf8") || "{}");
  } catch {
    const error = new Error("Request body is not valid JSON.");
    error.status = 400;
    error.code = "invalid_json";
    throw error;
  }
}

function requestOriginIsAllowed(request, allowedOrigin) {
  const origin = String(request.headers.origin || "");
  if (!origin) return true;
  if (allowedOrigin) return origin === allowedOrigin;
  const proto = request.headers["x-forwarded-proto"] || "http";
  return origin === `${proto}://${request.headers.host}`;
}

function cookieHeader(token, secure, maxAgeSeconds = 8 * 60 * 60) {
  return `${SESSION_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${maxAgeSeconds}${secure ? "; Secure" : ""}`;
}

function clearCookieHeader(secure) {
  return `${SESSION_COOKIE}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0${secure ? "; Secure" : ""}`;
}

function clientAddress(request) {
  return String(request.headers["cf-connecting-ip"] || request.socket.remoteAddress || "unknown").slice(0, 100);
}

export async function createApplicationServer(options = {}) {
  const production = options.production ?? process.env.NODE_ENV === "production";
  const staticDirectory = path.resolve(options.staticDirectory || DEFAULT_STATIC_DIRECTORY);
  const allowedOrigin = String(options.allowedOrigin ?? process.env.ALLOWED_ORIGIN ?? "").replace(/\/$/, "");
  const initialDirectorPassword = String(options.initialDirectorPassword ?? process.env.INITIAL_DIRECTOR_PASSWORD ?? (production ? "" : "Shubham@123"));
  if (!initialDirectorPassword) throw new Error("INITIAL_DIRECTOR_PASSWORD is required in production.");
  const store = await openStore({
    dataDirectory: options.dataDirectory,
    encryptionKey: options.encryptionKey,
    passwordPepper: options.passwordPepper,
    production,
  });
  await store.seedDirector(initialDirectorPassword);
  const loginAttempts = new Map();

  function currentSession(request) {
    const token = parseCookies(request.headers.cookie)[SESSION_COOKIE];
    const session = store.sessionFromToken(token);
    return session ? { ...session, token } : null;
  }

  function requireSession(request) {
    const session = currentSession(request);
    if (!session) {
      const error = new Error("Authentication is required.");
      error.status = 401;
      error.code = "unauthorized";
      throw error;
    }
    return session;
  }

  function requireMutationSecurity(request, session) {
    if (!requestOriginIsAllowed(request, allowedOrigin)) {
      const error = new Error("Request origin is not allowed.");
      error.status = 403;
      error.code = "origin_rejected";
      throw error;
    }
    if (!safeEqualText(request.headers["x-csrf-token"], session.csrfToken)) {
      const error = new Error("Security token is missing or invalid.");
      error.status = 403;
      error.code = "csrf_rejected";
      throw error;
    }
  }

  async function serveStatic(request, response, pathname) {
    const decoded = decodeURIComponent(pathname);
    const relative = decoded === "/" ? "index.html" : decoded.replace(/^\/+/, "");
    const candidate = path.resolve(staticDirectory, relative);
    if (!candidate.startsWith(`${staticDirectory}${path.sep}`) && candidate !== staticDirectory) return false;
    let filePath = candidate;
    try {
      if ((await stat(filePath)).isDirectory()) filePath = path.join(filePath, "index.html");
      const body = await readFile(filePath);
      const extension = path.extname(filePath).toLowerCase();
      response.writeHead(200, {
        "Content-Type": CONTENT_TYPES[extension] || "application/octet-stream",
        "Content-Length": body.length,
        "Cache-Control": extension === ".html" ? "no-store" : "public, max-age=3600",
      });
      response.end(body);
      return true;
    } catch (error) {
      if (error?.code !== "ENOENT") throw error;
      return false;
    }
  }

  const server = createHttpServer(async (request, response) => {
    securityHeaders(request, response, production);
    const url = new URL(request.url || "/", `http://${request.headers.host || "localhost"}`);
    try {
      if (url.pathname === "/api/health" && request.method === "GET") {
        return json(response, 200, { ok: true, service: "neelavati-secure-backend" });
      }

      if (url.pathname === "/api/auth/login" && request.method === "POST") {
        if (!requestOriginIsAllowed(request, allowedOrigin)) {
          const error = new Error("Request origin is not allowed.");
          error.status = 403;
          error.code = "origin_rejected";
          throw error;
        }
        const body = await readJsonBody(request);
        const attemptKey = `${clientAddress(request)}:${String(body.loginId || "").toLowerCase()}`;
        const history = (loginAttempts.get(attemptKey) || []).filter((time) => Date.now() - time < LOGIN_WINDOW_MS);
        if (history.length >= LOGIN_LIMIT) {
          response.setHeader("Retry-After", "900");
          const error = new Error("Too many login attempts. Try again later.");
          error.status = 429;
          error.code = "login_limited";
          throw error;
        }
        const user = await store.authenticate(body.loginId, body.password);
        if (!user) {
          history.push(Date.now());
          loginAttempts.set(attemptKey, history);
          const error = new Error("Login ID or password is incorrect.");
          error.status = 401;
          error.code = "invalid_credentials";
          throw error;
        }
        loginAttempts.delete(attemptKey);
        const session = store.createSession(user.id);
        const secure = production || request.headers["x-forwarded-proto"] === "https";
        return json(response, 200, { user, csrfToken: session.csrfToken, expiresAt: session.expiresAt }, {
          "Set-Cookie": cookieHeader(session.rawToken, secure),
          "Cache-Control": "no-store",
        });
      }

      if (url.pathname === "/api/auth/me" && request.method === "GET") {
        const session = requireSession(request);
        return json(response, 200, { user: session.user, csrfToken: session.csrfToken, expiresAt: session.expiresAt }, { "Cache-Control": "no-store" });
      }

      if (url.pathname === "/api/auth/logout" && request.method === "POST") {
        const session = requireSession(request);
        requireMutationSecurity(request, session);
        await store.deleteSession(session.token, session.user.id);
        const secure = production || request.headers["x-forwarded-proto"] === "https";
        return json(response, 200, { ok: true }, { "Set-Cookie": clearCookieHeader(secure), "Cache-Control": "no-store" });
      }

      if (url.pathname === "/api/state" && request.method === "GET") {
        const session = requireSession(request);
        const state = store.readState();
        return json(response, 200, {
          ...state,
          employees: store.listUsers(session.user.designation === "Director"),
          incentiveProfile: store.recoveryIncentiveProfile(session.user.id),
          workingProfile: store.employeeWorkingProfile(session.user.id),
          teamWorkingProfiles: store.assistantManagerTeamWorkingProfiles(session.user.id),
        }, { "Cache-Control": "no-store" });
      }

      if (url.pathname === "/api/state" && request.method === "PUT") {
        const session = requireSession(request);
        requireMutationSecurity(request, session);
        const body = await readJsonBody(request);
        const saved = await store.saveState(session.user, body.data, body.baseVersion);
        return json(response, 200, { version: saved.version, updatedAt: saved.updatedAt });
      }

      if (url.pathname === "/api/users" && request.method === "GET") {
        const session = requireSession(request);
        if (!["Director", "Manager"].includes(session.user.designation)) {
          const error = new Error("Employee management access is required.");
          error.status = 403;
          error.code = "forbidden";
          throw error;
        }
        return json(response, 200, {
          users: store.listUsers(session.user.designation === "Director"),
        }, { "Cache-Control": "no-store" });
      }

      if (url.pathname === "/api/users" && request.method === "POST") {
        const session = requireSession(request);
        requireMutationSecurity(request, session);
        const user = await store.createUser(session.user, await readJsonBody(request));
        return json(response, 201, { user });
      }

      const userAssistantManagerMatch = /^\/api\/users\/(\d+)\/assistant-manager$/.exec(url.pathname);
      if (userAssistantManagerMatch && request.method === "PATCH") {
        const session = requireSession(request);
        requireMutationSecurity(request, session);
        const body = await readJsonBody(request);
        await store.assignStaffAssistantManager(session.user, Number(userAssistantManagerMatch[1]), body.assistantManagerLoginId);
        return json(response, 200, { ok: true });
      }

      const userTeamIncentiveMatch = /^\/api\/users\/(\d+)\/team-incentive$/.exec(url.pathname);
      if (userTeamIncentiveMatch && request.method === "PATCH") {
        const session = requireSession(request);
        requireMutationSecurity(request, session);
        const body = await readJsonBody(request);
        await store.updateTeamIncentive(session.user, Number(userTeamIncentiveMatch[1]), body.incentive);
        return json(response, 200, { ok: true });
      }

      const userRecurringDepositMatch = /^\/api\/users\/(\d+)\/recurring-deposit$/.exec(url.pathname);
      if (userRecurringDepositMatch && request.method === "PATCH") {
        const session = requireSession(request);
        requireMutationSecurity(request, session);
        const body = await readJsonBody(request);
        await store.updateRecurringDeposit(session.user, Number(userRecurringDepositMatch[1]), body.recurringDeposit);
        return json(response, 200, { ok: true });
      }

      const recoveryStaffMatch = /^\/api\/loans\/([^/]+)\/recovery-staff$/.exec(url.pathname);
      if (recoveryStaffMatch && request.method === "PATCH") {
        const session = requireSession(request);
        requireMutationSecurity(request, session);
        const body = await readJsonBody(request);
        const result = await store.reassignRecoveryStaff(session.user, decodeURIComponent(recoveryStaffMatch[1]), body.staffLoginId);
        return json(response, 200, result);
      }

      const userDeleteMatch = /^\/api\/users\/(\d+)$/.exec(url.pathname);
      if (userDeleteMatch && request.method === "DELETE") {
        const session = requireSession(request);
        requireMutationSecurity(request, session);
        await store.deactivateUser(session.user, Number(userDeleteMatch[1]));
        return json(response, 200, { ok: true });
      }

      if (url.pathname === "/api/audit" && request.method === "GET") {
        const session = requireSession(request);
        if (session.user.designation !== "Director") {
          const error = new Error("Director access is required.");
          error.status = 403;
          error.code = "forbidden";
          throw error;
        }
        return json(response, 200, { entries: store.readAudit(url.searchParams.get("limit")) }, { "Cache-Control": "no-store" });
      }

      if (url.pathname.startsWith("/api/")) return json(response, 404, { error: "not_found", message: "API route was not found." });
      if (request.method !== "GET" && request.method !== "HEAD") return json(response, 405, { error: "method_not_allowed", message: "Method is not allowed." });
      if (await serveStatic(request, response, url.pathname)) return;
      if (await serveStatic(request, response, "/index.html")) return;
      return json(response, 404, { error: "not_found", message: "Page was not found." });
    } catch (error) {
      const status = Number(error.status) || 500;
      if (status >= 500) console.error("Request failed", error);
      return json(response, status, {
        error: error.code || "server_error",
        message: status >= 500 ? "The server could not complete the request." : error.message,
        ...(error.details ? { details: error.details } : {}),
      }, { "Cache-Control": "no-store" });
    }
  });

  server.on("close", () => store.close());
  return { server, store };
}

async function startFromCommandLine() {
  const host = process.env.HOST || "127.0.0.1";
  const port = Number(process.env.PORT || 8787);
  const { server, store } = await createApplicationServer();
  server.listen(port, host, () => {
    console.log(`NEELAVATI secure server listening on http://${host}:${port}`);
    console.log(`Encrypted database: ${store.databasePath}`);
  });
}

if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  startFromCommandLine().catch((error) => {
    console.error(error);
    process.exitCode = 1;
  });
}
