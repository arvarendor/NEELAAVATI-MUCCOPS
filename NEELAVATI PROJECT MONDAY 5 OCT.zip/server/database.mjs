import { DatabaseSync } from "node:sqlite";
import { mkdir } from "node:fs/promises";
import path from "node:path";
import {
  decryptJson,
  encryptJson,
  hashPassword,
  loadMasterKey,
  normalizeLogin,
  randomToken,
  tokenHash,
  validatePassword,
  verifyPassword,
} from "./security.mjs";

const ROLES = ["Director", "Manager", "Assistant Manager", "Cashier", "Executive", "Staff"];
const STATE_KEYS = ["groups", "loans", "cashEntries", "bankHolidays", "npaRegistry", "workingRecords", "oldDataImportHistory"];
const WRITE_ACCESS = {
  Director: new Set(STATE_KEYS),
  Manager: new Set(["groups", "loans", "cashEntries", "bankHolidays", "npaRegistry"]),
  "Assistant Manager": new Set(["groups"]),
  Cashier: new Set(["loans", "cashEntries", "npaRegistry", "workingRecords"]),
  Executive: new Set(["loans", "cashEntries", "npaRegistry"]),
  Staff: new Set(["loans", "cashEntries", "npaRegistry"]),
};

const EMPTY_STATE = Object.freeze({
  groups: [],
  loans: [],
  cashEntries: [],
  bankHolidays: [],
  npaRegistry: [],
  workingRecords: [],
  oldDataImportHistory: [],
});

function cloneEmptyState() {
  return Object.fromEntries(Object.entries(EMPTY_STATE).map(([key]) => [key, []]));
}

function sanitizeUser(row, includeCompensation = false) {
  const user = {
    id: row.id,
    name: row.name,
    loginId: row.login_id,
    designation: row.role,
    managerId: row.manager_user_id || null,
    managerLoginId: row.manager_login_id || "",
    managerName: row.manager_name || "",
    assistantManagerId: row.assistant_manager_user_id || null,
    assistantManagerLoginId: row.assistant_manager_login_id || "",
    assistantManagerName: row.assistant_manager_name || "",
    active: Boolean(row.active),
    lastActive: row.last_active || "Never",
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
  if (includeCompensation) Object.assign(user, {
    salary: Number(row.salary || 0),
    performanceAllowance: Number(row.performance_allowance || 0),
    petrolAllowance: Number(row.petrol_allowance || 0),
    businessAllowance: Number(row.business_allowance || 0),
    incentive: Number(row.incentive || 0),
    recurringDeposit: Number(row.recurring_deposit || 0),
    recurringDepositStartedAt: row.recurring_deposit_started_at || "",
  });
  return user;
}

function nowIso() {
  return new Date().toISOString();
}

function appError(status, code, message, details) {
  const error = new Error(message);
  error.status = status;
  error.code = code;
  error.details = details;
  return error;
}

export async function openStore(options = {}) {
  const dataDirectory = path.resolve(options.dataDirectory || path.join(process.cwd(), ".data"));
  await mkdir(dataDirectory, { recursive: true });
  const production = options.production ?? process.env.NODE_ENV === "production";
  const masterKey = await loadMasterKey(dataDirectory, options.encryptionKey ?? process.env.DATA_ENCRYPTION_KEY, production);
  const pepper = String(options.passwordPepper ?? process.env.PASSWORD_PEPPER ?? "");
  if (production && !pepper) throw new Error("PASSWORD_PEPPER is required in production.");

  const databasePath = path.join(dataDirectory, "neelavati.db");
  const db = new DatabaseSync(databasePath);
  db.exec("PRAGMA journal_mode=WAL; PRAGMA foreign_keys=ON; PRAGMA busy_timeout=5000;");
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL,
      login_id TEXT NOT NULL UNIQUE COLLATE NOCASE,
      password_hash TEXT NOT NULL,
      password_salt TEXT NOT NULL,
      role TEXT NOT NULL,
      active INTEGER NOT NULL DEFAULT 1,
      protected INTEGER NOT NULL DEFAULT 0,
      manager_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      assistant_manager_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
      salary INTEGER NOT NULL DEFAULT 0,
      performance_allowance INTEGER NOT NULL DEFAULT 0,
      petrol_allowance INTEGER NOT NULL DEFAULT 0,
      business_allowance INTEGER NOT NULL DEFAULT 0,
      incentive INTEGER NOT NULL DEFAULT 0,
      recurring_deposit INTEGER NOT NULL DEFAULT 0,
      recurring_deposit_started_at TEXT,
      last_active TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sessions (
      token_hash TEXT PRIMARY KEY,
      user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
      csrf_token TEXT NOT NULL,
      created_at TEXT NOT NULL,
      expires_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS sessions_user_id ON sessions(user_id);
    CREATE INDEX IF NOT EXISTS sessions_expires_at ON sessions(expires_at);
    CREATE TABLE IF NOT EXISTS application_state (
      id INTEGER PRIMARY KEY CHECK (id = 1),
      ciphertext TEXT NOT NULL,
      iv TEXT NOT NULL,
      tag TEXT NOT NULL,
      version INTEGER NOT NULL,
      updated_at TEXT NOT NULL,
      updated_by INTEGER REFERENCES users(id)
    );
    CREATE TABLE IF NOT EXISTS audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id INTEGER REFERENCES users(id),
      action TEXT NOT NULL,
      details_json TEXT NOT NULL,
      created_at TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS audit_log_created_at ON audit_log(created_at DESC);
  `);

  const userColumns = new Set(db.prepare("PRAGMA table_info(users)").all().map((column) => column.name));
  const userMigrations = [
    ["manager_user_id", "ALTER TABLE users ADD COLUMN manager_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL"],
    ["assistant_manager_user_id", "ALTER TABLE users ADD COLUMN assistant_manager_user_id INTEGER REFERENCES users(id) ON DELETE SET NULL"],
    ["salary", "ALTER TABLE users ADD COLUMN salary INTEGER NOT NULL DEFAULT 0"],
    ["performance_allowance", "ALTER TABLE users ADD COLUMN performance_allowance INTEGER NOT NULL DEFAULT 0"],
    ["petrol_allowance", "ALTER TABLE users ADD COLUMN petrol_allowance INTEGER NOT NULL DEFAULT 0"],
    ["business_allowance", "ALTER TABLE users ADD COLUMN business_allowance INTEGER NOT NULL DEFAULT 0"],
    ["incentive", "ALTER TABLE users ADD COLUMN incentive INTEGER NOT NULL DEFAULT 0"],
    ["recurring_deposit", "ALTER TABLE users ADD COLUMN recurring_deposit INTEGER NOT NULL DEFAULT 0"],
    ["recurring_deposit_started_at", "ALTER TABLE users ADD COLUMN recurring_deposit_started_at TEXT"],
  ];
  for (const [column, statement] of userMigrations) {
    if (!userColumns.has(column)) db.exec(statement);
  }
  db.exec(`UPDATE users
    SET recurring_deposit_started_at = substr(created_at, 1, 7)
    WHERE recurring_deposit > 0 AND (recurring_deposit_started_at IS NULL OR recurring_deposit_started_at = '')`);

  const encryptedEmpty = encryptJson(cloneEmptyState(), masterKey);
  db.prepare(`INSERT OR IGNORE INTO application_state
    (id, ciphertext, iv, tag, version, updated_at, updated_by)
    VALUES (1, ?, ?, ?, 0, ?, NULL)`)
    .run(encryptedEmpty.ciphertext, encryptedEmpty.iv, encryptedEmpty.tag, nowIso());

  async function audit(userId, action, details = {}) {
    db.prepare("INSERT INTO audit_log (user_id, action, details_json, created_at) VALUES (?, ?, ?, ?)")
      .run(userId || null, action, JSON.stringify(details), nowIso());
  }

  async function seedDirector(password) {
    const existing = db.prepare("SELECT id FROM users WHERE login_id = ?").get("shubham");
    if (existing) return;
    const issue = validatePassword(password);
    if (issue) throw new Error(`INITIAL_DIRECTOR_PASSWORD: ${issue}`);
    const secured = await hashPassword(password, pepper);
    const now = nowIso();
    db.prepare(`INSERT INTO users
      (name, login_id, password_hash, password_salt, role, active, protected, created_at, updated_at)
      VALUES (?, ?, ?, ?, 'Director', 1, 1, ?, ?)`)
      .run("Shubham", "shubham", secured.hash, secured.salt, now, now);
    await audit(null, "director.seeded", { loginId: "shubham" });
  }

  async function authenticate(loginId, password) {
    const normalized = normalizeLogin(loginId);
    const row = db.prepare("SELECT * FROM users WHERE login_id = ? AND active = 1").get(normalized);
    if (!row || !(await verifyPassword(password, row.password_salt, row.password_hash, pepper))) return null;
    const now = nowIso();
    db.prepare("UPDATE users SET last_active = ?, updated_at = ? WHERE id = ?").run(now, now, row.id);
    await audit(row.id, "auth.login", {});
    return sanitizeUser({ ...row, last_active: now, updated_at: now });
  }

  function userById(userId) {
    return db.prepare(`SELECT u.*, manager.name AS manager_name, manager.login_id AS manager_login_id,
      assistant.name AS assistant_manager_name, assistant.login_id AS assistant_manager_login_id
      FROM users u LEFT JOIN users manager ON manager.id = u.manager_user_id
      LEFT JOIN users assistant ON assistant.id = u.assistant_manager_user_id
      WHERE u.id = ?`).get(Number(userId));
  }

  function listUsers(includeCompensation = false) {
    return db.prepare(`SELECT u.*, manager.name AS manager_name, manager.login_id AS manager_login_id,
      assistant.name AS assistant_manager_name, assistant.login_id AS assistant_manager_login_id
      FROM users u LEFT JOIN users manager ON manager.id = u.manager_user_id
      LEFT JOIN users assistant ON assistant.id = u.assistant_manager_user_id
      ORDER BY u.active DESC, u.name COLLATE NOCASE`).all().map((row) => sanitizeUser(row, includeCompensation));
  }

  function recoveryIncentiveProfile(userId) {
    const row = userById(userId);
    if (!row || !["Manager", "Assistant Manager", "Staff"].includes(row.role)) return null;
    return {
      loginId: row.login_id,
      incentive: Math.max(0, Number(row.incentive || 0)),
    };
  }

  function employeeWorkingProfile(userId) {
    const row = userById(userId);
    if (!row || !["Manager", "Assistant Manager", "Cashier", "Executive", "Staff"].includes(row.role)) return null;
    return {
      loginId: row.login_id,
      salary: Math.max(0, Number(row.salary || 0)),
      recoveryAllowance: ["Manager", "Assistant Manager"].includes(row.role) ? 0 : Math.max(0, Number(row.petrol_allowance || 0)),
      businessAllowance: ["Manager", "Assistant Manager"].includes(row.role) ? 0 : Math.max(0, Number(row.business_allowance || 0)),
      incentive: ["Manager", "Assistant Manager", "Staff"].includes(row.role) ? Math.max(0, Number(row.incentive || 0)) : 0,
      recurringDeposit: ["Manager", "Assistant Manager", "Staff"].includes(row.role) ? Math.max(0, Number(row.recurring_deposit || 0)) : 0,
      recurringDepositStartedAt: ["Manager", "Assistant Manager", "Staff"].includes(row.role) ? String(row.recurring_deposit_started_at || "") : "",
    };
  }

  function assistantManagerTeamWorkingProfiles(userId) {
    const assistant = userById(userId);
    if (!assistant || assistant.role !== "Assistant Manager") return [];
    return db.prepare(`SELECT u.*, manager.name AS manager_name, manager.login_id AS manager_login_id,
      assistant.name AS assistant_manager_name, assistant.login_id AS assistant_manager_login_id
      FROM users u LEFT JOIN users manager ON manager.id = u.manager_user_id
      LEFT JOIN users assistant ON assistant.id = u.assistant_manager_user_id
      WHERE u.active = 1 AND u.role = 'Staff' AND u.assistant_manager_user_id = ?
      ORDER BY u.name COLLATE NOCASE`).all(Number(userId)).map((row) => sanitizeUser(row, true));
  }

  async function createUser(actor, input) {
    if (!["Director", "Manager"].includes(actor.designation)) throw appError(403, "forbidden", "Employee management access is required.");
    const name = String(input.name || "").trim();
    const loginId = normalizeLogin(input.loginId);
    const role = String(input.designation || "").trim();
    if (!name || !/^[a-z0-9._-]{3,40}$/i.test(loginId)) throw appError(400, "invalid_user", "Enter a valid employee name and Login ID.");
    if (!ROLES.includes(role)) throw appError(400, "invalid_role", "Unknown employee designation.");
    if (actor.designation !== "Director" && role === "Director") throw appError(403, "forbidden", "Only a Director can create another Director.");
    const amount = (key) => {
      const value = Number(input[key] || 0);
      if (!Number.isFinite(value) || value < 0 || value > 100000000) {
        throw appError(400, "invalid_amount", "Salary and allowance amounts must be zero or more.");
      }
      return Math.round(value);
    };
    const managerLoginId = role === "Staff" ? normalizeLogin(input.managerLoginId) : "";
    const assistantManagerLoginId = role === "Staff" ? normalizeLogin(input.assistantManagerLoginId) : "";
    const manager = role === "Staff" && managerLoginId
      ? db.prepare("SELECT id, name, login_id FROM users WHERE login_id = ? AND role = 'Manager' AND active = 1")
        .get(managerLoginId)
      : null;
    const assistantManager = role === "Staff" && assistantManagerLoginId
      ? db.prepare("SELECT id, name, login_id FROM users WHERE login_id = ? AND role = 'Assistant Manager' AND active = 1")
        .get(assistantManagerLoginId)
      : null;
    if (managerLoginId && !manager) throw appError(400, "invalid_manager", "The selected Manager is not active.");
    if (assistantManagerLoginId && !assistantManager) throw appError(400, "invalid_assistant_manager", "The selected Assistant Manager is not active.");
    const extendedCompensation = ["Manager", "Assistant Manager", "Staff"].includes(role);
    const salary = amount("salary");
    const performanceAllowance = role === "Staff" ? amount("performanceAllowance") : 0;
    const petrolAllowance = role === "Staff" ? amount("petrolAllowance") : 0;
    const businessAllowance = role === "Staff" ? amount("businessAllowance") : 0;
    const incentive = extendedCompensation ? amount("incentive") : 0;
    const recurringDeposit = extendedCompensation ? amount("recurringDeposit") : 0;
    const issue = validatePassword(input.password);
    if (issue) throw appError(400, "weak_password", issue);
    if (db.prepare("SELECT id FROM users WHERE login_id = ?").get(loginId)) throw appError(409, "duplicate_login", "This Login ID is already assigned.");
    const secured = await hashPassword(input.password, pepper);
    const now = nowIso();
    const result = db.prepare(`INSERT INTO users
      (name, login_id, password_hash, password_salt, role, active, protected, manager_user_id, assistant_manager_user_id,
       salary, performance_allowance, petrol_allowance, business_allowance, incentive, recurring_deposit,
       recurring_deposit_started_at, created_at, updated_at)
      VALUES (?, ?, ?, ?, ?, 1, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`)
      .run(name, loginId, secured.hash, secured.salt, role, manager?.id || null, assistantManager?.id || null,
        salary, performanceAllowance, petrolAllowance, businessAllowance, incentive, recurringDeposit,
        recurringDeposit > 0 ? now.slice(0, 7) : null, now, now);
    await audit(actor.id, "user.created", {
      userId: Number(result.lastInsertRowid), loginId, role,
      managerLoginId: manager?.login_id || null,
      assistantManagerLoginId: assistantManager?.login_id || null,
      salary, performanceAllowance, petrolAllowance, businessAllowance, incentive, recurringDeposit,
    });
    return sanitizeUser(userById(Number(result.lastInsertRowid)), actor.designation === "Director");
  }

  async function deactivateUser(actor, userId) {
    if (!["Director", "Manager"].includes(actor.designation)) throw appError(403, "forbidden", "Employee management access is required.");
    const target = db.prepare("SELECT * FROM users WHERE id = ?").get(Number(userId));
    if (!target) throw appError(404, "not_found", "Employee account was not found.");
    if (target.protected) throw appError(403, "protected_account", "The primary Director account cannot be removed.");
    if (target.id === actor.id) throw appError(400, "self_remove", "You cannot remove your own active login.");
    if (actor.designation !== "Director" && target.role === "Director") throw appError(403, "forbidden", "Only a Director can remove another Director.");
    const now = nowIso();
    db.prepare("UPDATE users SET active = 0, updated_at = ? WHERE id = ?").run(now, target.id);
    db.prepare("DELETE FROM sessions WHERE user_id = ?").run(target.id);
    await audit(actor.id, "user.deactivated", { userId: target.id, loginId: target.login_id });
  }

  async function assignStaffAssistantManager(actor, staffUserId, assistantManagerLoginId) {
    if (actor.designation !== "Director") throw appError(403, "forbidden", "Only the Director can assign Assistant Manager teams.");
    const staff = db.prepare("SELECT * FROM users WHERE id = ? AND role = 'Staff' AND active = 1").get(Number(staffUserId));
    if (!staff) throw appError(404, "staff_not_found", "Active staff account was not found.");
    const assistant = db.prepare("SELECT * FROM users WHERE login_id = ? AND role = 'Assistant Manager' AND active = 1")
      .get(normalizeLogin(assistantManagerLoginId));
    if (!assistant) throw appError(400, "invalid_assistant_manager", "Select an active Assistant Manager.");
    const now = nowIso();
    db.prepare("UPDATE users SET assistant_manager_user_id = ?, updated_at = ? WHERE id = ?")
      .run(assistant.id, now, staff.id);
    await audit(actor.id, "staff.assistant_manager_assigned", {
      staffUserId: staff.id,
      staffLoginId: staff.login_id,
      assistantManagerUserId: assistant.id,
      assistantManagerLoginId: assistant.login_id,
    });
  }

  async function updateTeamIncentive(actor, userId, incentive) {
    if (actor.designation !== "Director") throw appError(403, "forbidden", "Only the Director can update team incentive rates.");
    const target = db.prepare("SELECT * FROM users WHERE id = ? AND role IN ('Manager', 'Assistant Manager') AND active = 1")
      .get(Number(userId));
    if (!target) throw appError(404, "team_leader_not_found", "Active Manager or Assistant Manager account was not found.");
    const amount = Number(incentive);
    if (!Number.isFinite(amount) || amount < 0 || amount > 100000000) {
      throw appError(400, "invalid_amount", "Team incentive must be zero or more.");
    }
    const roundedAmount = Math.round(amount);
    db.prepare("UPDATE users SET incentive = ?, updated_at = ? WHERE id = ?").run(roundedAmount, nowIso(), target.id);
    await audit(actor.id, "user.team_incentive_updated", {
      userId: target.id,
      loginId: target.login_id,
      incentive: roundedAmount,
    });
  }

  async function updateRecurringDeposit(actor, userId, recurringDeposit) {
    if (actor.designation !== "Director") throw appError(403, "forbidden", "Only the Director can update recurring deposits.");
    const target = db.prepare("SELECT * FROM users WHERE id = ? AND role IN ('Manager', 'Assistant Manager', 'Staff') AND active = 1")
      .get(Number(userId));
    if (!target) throw appError(404, "employee_not_found", "Active Manager, Assistant Manager, or Staff account was not found.");
    const amount = Number(recurringDeposit);
    if (!Number.isFinite(amount) || amount < 0 || amount > 100000000) {
      throw appError(400, "invalid_amount", "Recurring deposit must be zero or more.");
    }
    const roundedAmount = Math.round(amount);
    const updatedAt = nowIso();
    const legacyStartMonth = String(target.created_at || "").slice(0, 7);
    const existingStartMonth = /^\d{4}-(0[1-9]|1[0-2])$/.test(String(target.recurring_deposit_started_at || ""))
      ? target.recurring_deposit_started_at
      : Number(target.recurring_deposit || 0) > 0 && /^\d{4}-(0[1-9]|1[0-2])$/.test(legacyStartMonth)
        ? legacyStartMonth
        : updatedAt.slice(0, 7);
    const startedAt = roundedAmount > 0 ? existingStartMonth : null;
    db.prepare("UPDATE users SET recurring_deposit = ?, recurring_deposit_started_at = ?, updated_at = ? WHERE id = ?")
      .run(roundedAmount, startedAt, updatedAt, target.id);
    await audit(actor.id, "user.recurring_deposit_updated", {
      userId: target.id,
      loginId: target.login_id,
      recurringDeposit: roundedAmount,
      recurringDepositStartedAt: startedAt,
    });
  }

  async function reassignRecoveryStaff(actor, loanId, staffLoginId) {
    if (!["Director", "Cashier", "Assistant Manager"].includes(actor.designation)) {
      throw appError(403, "forbidden", "Only the Director, Cashier, or Assistant Manager can change recovery staff.");
    }
    const targetBase = db.prepare("SELECT * FROM users WHERE login_id = ? AND role = 'Staff' AND active = 1")
      .get(normalizeLogin(staffLoginId));
    if (!targetBase) throw appError(400, "invalid_recovery_staff", "Select an active Staff account.");
    const target = userById(targetBase.id);
    const current = readState();
    const loan = current.data.loans.find((item) => String(item.id || "") === String(loanId || ""));
    if (!loan) throw appError(404, "loan_not_found", "Loan record was not found.");

    const currentLogin = normalizeLogin(loan.recoveryStaffLoginId);
    if (currentLogin === target.login_id || (!currentLogin && String(loan.staff || "").toLowerCase() === String(target.name || "").toLowerCase())) {
      throw appError(400, "already_assigned", `${target.name} is already assigned to this centre.`);
    }

    const previousStaff = String(loan.staff || "Unassigned");
    loan.staff = target.name;
    loan.recoveryStaffLoginId = target.login_id;
    loan.recoveryManagerLoginId = target.manager_login_id || "";
    loan.recoveryManagerName = target.manager_name || "";
    loan.recoveryAssistantManagerLoginId = target.assistant_manager_login_id || "";
    loan.recoveryAssistantManagerName = target.assistant_manager_name || "";
    loan.staffAssignmentHistory = [
      ...(Array.isArray(loan.staffAssignmentHistory) ? loan.staffAssignmentHistory : []),
      {
        from: previousStaff,
        fromLoginId: currentLogin,
        to: target.name,
        toLoginId: target.login_id,
        changedAt: nowIso(),
        changedBy: actor.name || actor.loginId,
        changedByRole: actor.designation,
      },
    ];
    const group = current.data.groups.find((item) => item.code === loan.groupCode || item.code === loan.code || item.number === loan.groupNumber);
    if (group) group.recoveryStaff = target.name;

    const secured = encryptJson(current.data, masterKey);
    const nextVersion = current.version + 1;
    const updatedAt = nowIso();
    db.exec("BEGIN IMMEDIATE");
    try {
      const result = db.prepare(`UPDATE application_state SET ciphertext = ?, iv = ?, tag = ?, version = ?, updated_at = ?, updated_by = ?
        WHERE id = 1 AND version = ?`)
        .run(secured.ciphertext, secured.iv, secured.tag, nextVersion, updatedAt, actor.id, current.version);
      if (result.changes !== 1) throw appError(409, "version_conflict", "Data changed on another device. Reload before assigning recovery staff.");
      db.prepare("INSERT INTO audit_log (user_id, action, details_json, created_at) VALUES (?, ?, ?, ?)")
        .run(actor.id, "loan.recovery_staff_reassigned", JSON.stringify({
          loanId: loan.id,
          groupNumber: loan.groupNumber || "",
          from: previousStaff,
          to: target.name,
          toLoginId: target.login_id,
          version: nextVersion,
        }), updatedAt);
      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
    return { version: nextVersion, updatedAt, loan, group: group || null };
  }

  function createSession(userId, ttlHours = 8) {
    const rawToken = randomToken();
    const csrfToken = randomToken(24);
    const now = new Date();
    const expires = new Date(now.getTime() + ttlHours * 60 * 60 * 1000);
    db.prepare("DELETE FROM sessions WHERE expires_at <= ?").run(now.toISOString());
    db.prepare("INSERT INTO sessions (token_hash, user_id, csrf_token, created_at, expires_at) VALUES (?, ?, ?, ?, ?)")
      .run(tokenHash(rawToken), userId, csrfToken, now.toISOString(), expires.toISOString());
    return { rawToken, csrfToken, expiresAt: expires.toISOString() };
  }

  function sessionFromToken(rawToken) {
    if (!rawToken) return null;
    const row = db.prepare(`SELECT s.csrf_token, s.expires_at, u.*
      FROM sessions s JOIN users u ON u.id = s.user_id
      WHERE s.token_hash = ? AND s.expires_at > ? AND u.active = 1`)
      .get(tokenHash(rawToken), nowIso());
    if (!row) return null;
    return { user: sanitizeUser(row), csrfToken: row.csrf_token, expiresAt: row.expires_at };
  }

  async function deleteSession(rawToken, userId) {
    if (rawToken) db.prepare("DELETE FROM sessions WHERE token_hash = ?").run(tokenHash(rawToken));
    await audit(userId, "auth.logout", {});
  }

  function readState() {
    const row = db.prepare("SELECT * FROM application_state WHERE id = 1").get();
    const decrypted = decryptJson(row, masterKey);
    const data = { ...cloneEmptyState(), ...(decrypted && typeof decrypted === "object" ? decrypted : {}) };
    STATE_KEYS.forEach((key) => {
      if (!Array.isArray(data[key])) data[key] = [];
    });
    return { data, version: row.version, updatedAt: row.updated_at };
  }

  async function saveState(actor, nextState, baseVersion) {
    if (!nextState || typeof nextState !== "object" || Array.isArray(nextState)) throw appError(400, "invalid_state", "Application state must be an object.");
    const current = readState();
    if (Number(baseVersion) !== current.version) throw appError(409, "version_conflict", "Data changed on another device. Reload before saving.", { currentVersion: current.version });
    const allowed = WRITE_ACCESS[actor.designation] || new Set();
    const merged = { ...current.data };
    const changed = [];
    for (const key of STATE_KEYS) {
      if (!(key in nextState)) continue;
      if (!Array.isArray(nextState[key])) throw appError(400, "invalid_state", `${key} must be an array.`);
      if (JSON.stringify(nextState[key]) === JSON.stringify(current.data[key])) continue;
      if (!allowed.has(key)) throw appError(403, "forbidden_state_change", `${actor.designation} cannot modify ${key}.`);
      merged[key] = nextState[key];
      changed.push(key);
    }
    if (!changed.length) return current;
    const secured = encryptJson(merged, masterKey);
    const nextVersion = current.version + 1;
    const updatedAt = nowIso();
    db.exec("BEGIN IMMEDIATE");
    try {
      const result = db.prepare(`UPDATE application_state SET ciphertext = ?, iv = ?, tag = ?, version = ?, updated_at = ?, updated_by = ?
        WHERE id = 1 AND version = ?`)
        .run(secured.ciphertext, secured.iv, secured.tag, nextVersion, updatedAt, actor.id, current.version);
      if (result.changes !== 1) throw appError(409, "version_conflict", "Data changed on another device. Reload before saving.");
      db.prepare("INSERT INTO audit_log (user_id, action, details_json, created_at) VALUES (?, ?, ?, ?)")
        .run(actor.id, "state.updated", JSON.stringify({ changed, version: nextVersion }), updatedAt);
      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
    return { data: merged, version: nextVersion, updatedAt };
  }

  function readAudit(limit = 100) {
    return db.prepare(`SELECT a.id, a.action, a.details_json, a.created_at, u.name AS user_name, u.login_id
      FROM audit_log a LEFT JOIN users u ON u.id = a.user_id ORDER BY a.id DESC LIMIT ?`)
      .all(Math.max(1, Math.min(500, Number(limit) || 100)))
      .map((row) => ({
        id: row.id,
        action: row.action,
        details: JSON.parse(row.details_json || "{}"),
        createdAt: row.created_at,
        userName: row.user_name || "System",
        loginId: row.login_id || "",
      }));
  }

  function close() {
    db.close();
  }

  return {
    databasePath,
    seedDirector,
    authenticate,
    listUsers,
    recoveryIncentiveProfile,
    employeeWorkingProfile,
    assistantManagerTeamWorkingProfiles,
    createUser,
    deactivateUser,
    assignStaffAssistantManager,
    updateTeamIncentive,
    updateRecurringDeposit,
    reassignRecoveryStaff,
    createSession,
    sessionFromToken,
    deleteSession,
    readState,
    saveState,
    readAudit,
    close,
  };
}

export { ROLES, appError };
