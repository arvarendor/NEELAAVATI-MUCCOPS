const fs = require("fs");
const assert = require("assert");
const path = require("path");

const html = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const app = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const server = fs.readFileSync(path.join(__dirname, "server", "server.mjs"), "utf8");
const database = fs.readFileSync(path.join(__dirname, "server", "database.mjs"), "utf8");

assert.match(html, /id="myWorkingContent"/, "The Staff incentive display must live inside the My Working core feature");

assert.match(app, /function staffIncentiveEvents\(account\)/, "Approved centre events must drive Staff incentive income");
assert.match(app, /\["recovery", "advance", "closing"\][\s\S]*enteredByRole[\s\S]*approvedAt/, "Only approved Staff collection entries may earn incentive");
assert.match(app, /const key = `\$\{date\}\|\$\{centreKey\}`/, "One centre may earn incentive only once per recovery date");
assert.match(app, /incentiveRate: role\(\) === "Staff" \? currentStaffIncentiveRate\(\) : 0/, "The Staff rate must be captured when a proposal is submitted");
assert.match(app, /usesRecoveryIncentive\(account\.designation\)[\s\S]*employeeCurrentMonthIncentive\(account\)/, "Payroll must use earned monthly recovery incentive instead of treating the rate as fixed income");
assert.match(app, /Staff: \["recovery", "approvals", "working", "hold"\]/, "Staff must have access to the My Working core feature");
assert.match(app, /renderEmployeeWorking\(host, account\)/, "The live personal incentive must render inside the My Working core feature");
assert.match(server, /incentiveProfile: store\.recoveryIncentiveProfile\(session\.user\.id\)/, "Secure state must return only the signed-in employee's recovery incentive profile");
assert.match(database, /function recoveryIncentiveProfile\(userId\)[\s\S]*"Manager", "Assistant Manager", "Staff"[\s\S]*incentive:/, "Secure database must expose only eligible recovery incentive roles' own rate");

console.log("PASS: Staff incentive is credited once per approved centre recovery and displayed in My Working");
