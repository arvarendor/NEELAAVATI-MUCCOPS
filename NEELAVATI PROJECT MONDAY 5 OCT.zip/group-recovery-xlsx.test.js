const fs = require("fs");
const path = require("path");
const assert = require("assert");
const JSZip = require("./vendor/jszip.min.js");
const { buildGroupRecoveryWorkbook } = require("./recovery-demand-xlsx.js");

(async () => {
  const output = await buildGroupRecoveryWorkbook({
    outputType: "nodebuffer",
    sheetName: "G1",
    groupNumber: "G1",
    centreId: "G1(A1-A05)",
    centreName: "CHANDMARI NAGAR",
    recoveryDay: "Thursday",
    recoveryTime: "10:00",
    recoveryAmount: 3000,
    memberCount: 5,
    centreAddress: "PLOT NO. 38, CHANDMARI NAGAR WATHODA NAGPUR",
    groupLoanAmount: 50000,
    leader1: "NAZMIN KAZI",
    leader2: "SHAHIN SALAM",
    executiveName: "DINESH DHURVE",
    schedule: [
      { number: 1, date: "2024-04-11", groupEmi: "", updateTime: "10:42 AM", emi: 3000, advance: 200, closing: "", attendance: 5, review: "RECOVERY UPDATED" },
      { type: "holiday", date: "2024-04-18", holidayName: "BANK HOLIDAY" },
      { type: "closing", number: 2, date: "2024-04-25", groupEmi: "", updateTime: "03:15 PM", emi: "", advance: "", closing: 4800, attendance: 5, review: "LOAN CLOSE" },
    ],
  });
  const zip = await JSZip.loadAsync(output);
  const worksheet = await zip.file("xl/worksheets/sheet1.xml").async("string");
  const styles = await zip.file("xl/styles.xml").async("string");
  const workbook = await zip.file("xl/workbook.xml").async("string");
  const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");

  assert.match(worksheet, /NEELAVATI M\.U\.C\.CO-OP\.S \. LTD\./, "Workbook must use the sample's NEELAVATI title");
  assert.match(worksheet, /NGP\/RSR\/CR\/1542\/2024/, "Workbook must include the sample registration heading");
  assert.match(worksheet, /CENTRE ID[\s\S]*G1\(A1-A05\)[\s\S]*CENTRE NAME[\s\S]*CHANDMARI NAGAR/, "Workbook must include the centre detail block");
  assert.match(worksheet, /<row r="15"[\s\S]*UPDATE[\s\S]*GROUP[\s\S]*EMI[\s\S]*ADVANCE[\s\S]*CLOSING[\s\S]*ATTEND[\s\S]*REVIEW[\s\S]*<row r="16"[\s\S]*TIME[\s\S]*EMI[\s\S]*MEMBER/, "Workbook must keep the two-row weekly headers with the new collection fields");
  assert.doesNotMatch(worksheet, /RECIPT|TIME'|>IN<|>OUT</, "Receipt number and the old Time In/Time Out headings must be removed");
  assert.doesNotMatch(worksheet, />RD</, "Weekly Group Recovery must not include a Group RD column");
  assert.match(worksheet, /mergeCell ref="A1:I2"/, "Title must span the nine-column layout");
  assert.match(worksheet, /<c r="D17" s="11"\/>/, "Group EMI entry cells must be blank for staff to fill manually");
  assert.match(worksheet, /<c r="D19" s="14"\/>/, "Group EMI must stay blank even when a recovery exists");
  assert.match(worksheet, /<c r="C17" s="8" t="inlineStr"><is><t>10:42 AM<\/t><\/is><\/c>/, "The staff recovery update time must replace receipt number");
  assert.match(worksheet, /<c r="E17" s="11"><v>3000<\/v><\/c>/, "Normal recovery must be exported in the EMI column");
  assert.match(worksheet, /<c r="F17" s="11"><v>200<\/v><\/c>/, "Advance recovery must be exported in the Advance column");
  assert.match(worksheet, /<c r="G19" s="14"><v>4800<\/v><\/c>/, "Closing recovery must be exported in the Closing column");
  assert.match(worksheet, /pane ySplit="16"/, "Weekly rows must remain visible below frozen headings");
  assert.match(worksheet, /BANK HOLIDAY/, "Holiday rows must carry the holiday name");
  assert.match(styles, /FF8496B0/, "Weekly header must use the sample's blue-grey fill");
  assert.match(styles, /FFFFFF00/, "Holiday rows must be highlighted");
  assert.match(workbook, /\$A\$1:\$I\$/, "Print area must cover all nine export columns");
  assert.match(appSource, /buildGroupRecoveryWorkbook/, "Loan Record download must call the real XLSX builder");
  assert.match(appSource, /recoveryUpdateTimestamp[\s\S]*enteredAt/, "The screen must derive update time automatically from the recorded staff timestamp");
  assert.match(appSource, /<th>Update time<\/th>[\s\S]*<th>Group EMI<\/th>[\s\S]*<th>EMI<\/th>[\s\S]*<th>Advance<\/th>[\s\S]*<th>Closing<\/th>/, "The screen must use the same update-time and recovery columns as Excel");
  assert.match(appSource, /\.xlsx`/, "Weekly Group Recovery must download as an XLSX file");
  assert.doesNotMatch(appSource.slice(appSource.indexOf("async function downloadGroupSchedule"), appSource.indexOf("function downloadCustomerSchedule")), /csvDownload/, "Weekly Group Recovery must no longer download CSV");

  console.log("PASS: Weekly Group Recovery exports as the uploaded G-01 Excel design");
})().catch((error) => {
  console.error(error);
  process.exit(1);
});
