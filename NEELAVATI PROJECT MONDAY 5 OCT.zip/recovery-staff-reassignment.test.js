const fs = require("fs");
const assert = require("assert");
const path = require("path");

const app = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const api = fs.readFileSync(path.join(__dirname, "api.js"), "utf8");
const server = fs.readFileSync(path.join(__dirname, "server", "server.mjs"), "utf8");
const database = fs.readFileSync(path.join(__dirname, "server", "database.mjs"), "utf8");

assert.match(app, /function canReassignRecoveryStaff\(\)[\s\S]*\["Director", "Cashier", "Assistant Manager"\]/, "Only Director, Cashier and Assistant Manager may reassign recovery staff");
assert.match(app, /function activeRecoveryStaffAccounts\(\)[\s\S]*account\.active !== false[\s\S]*account\.designation === "Staff"/, "Replacement choices must contain only active Staff accounts");
assert.match(app, /data-recovery-staff-select[\s\S]*data-reassign-recovery-staff/, "Recovery Demand must show an inline replacement selector and Assign action");
assert.match(app, /Recovery Staff Assignment[\s\S]*data-global-recovery-staff-select/, "Authorized roles must have a global centre assignment register without exposing other teams' demand details");
assert.match(app, /staffAssignmentHistory[\s\S]*changedByRole/, "Every local staff transfer must keep an audit history");
assert.match(app, /recoveryAssistantManagerLoginId[\s\S]*!assignedAccount/, "Assistant Manager scope must retain inactive and orphaned centre recovery access");
assert.match(api, /reassignRecoveryStaff\(loanId, staffLoginId\)[\s\S]*\/recovery-staff/, "Frontend API must expose the narrow reassignment endpoint");
assert.match(server, /recoveryStaffMatch[\s\S]*store\.reassignRecoveryStaff/, "Secure server must route recovery reassignment");
assert.match(database, /async function reassignRecoveryStaff\(actor, loanId, staffLoginId\)[\s\S]*loan\.recovery_staff_reassigned/, "Secure database must validate and audit transfers");
assert.doesNotMatch(database, /You can reassign only your team/, "Assistant Manager must be able to redistribute any centre recovery");
assert.match(database, /"Assistant Manager": new Set\(\["groups"\]\)/, "Assistant Manager must not receive broad loan-state write access");

console.log("PASS: centre recovery staff can be securely reassigned and audited by authorized roles");
