const fs = require("fs");
const vm = require("vm");
const assert = require("assert");

const appPath = require("path").join(__dirname, "app.js");
const appSource = fs.readFileSync(appPath, "utf8");
const htmlSource = fs.readFileSync(require("path").join(__dirname, "index.html"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
const storage = new Map();
const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: {
    querySelector: () => null,
    querySelectorAll: () => [],
    createElement: () => ({ className: "", innerHTML: "", remove() {} }),
  },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  groups = [{ code: "NMC-TEST", number: "G99", name: "Test Centre", members: [{ name: "NPA Test", uuid: "1234 5678 9012", guarantor: "NPA Guarantor", guarantorAadhaar: "2345 6789 0123" }] }];
  loans = [{ groupCode: "NMC-TEST", groupNumber: "G99", groupName: "Test Centre", individualLoans: [{ memberIndex: 0, balance: 12000, emi: 600 }] }];
  npaRegistry = [];
  memberOverdueInfo = () => ({ overdue: true, days: 30, dueDate: "2026-07-01", npa: true });
  assessOverduePenalties("2026-07-31");
  const aadhaarInput = { value: "9999 8888 7777" };
  const guarantorAadhaarInput = { value: "2345 6789 0123" };
  const statusLabel = { textContent: "Approved" };
  const decisionButtons = [{ disabled: false, classList: { remove() {} } }, { disabled: false, classList: { remove() {} } }];
  let npaAlert = null;
  const fakeMember = {
    dataset: { status: "Approved" },
    classList: { add() {}, remove() {} },
    querySelector(selector) {
      if (selector === ".m-uuid") return aadhaarInput;
      if (selector === ".m-guarantor-aadhaar") return guarantorAadhaarInput;
      if (selector === ".decision-status") return statusLabel;
      if (selector === ".npa-customer-alert") return npaAlert;
      if (selector === ".member-title") return { insertAdjacentElement(_position, element) { npaAlert = element; } };
      return null;
    },
    querySelectorAll: () => decisionButtons,
  };
  updateMemberNpaStatus(fakeMember);
  globalThis.__result = {
    registry: JSON.parse(JSON.stringify(npaRegistry)),
    formattedMatch: Boolean(npaRegistryMatch("1234-5678-9012")),
    guarantorMatch: Boolean(npaRegistryMatch("2345-6789-0123")),
    shortNumberMatch: Boolean(npaRegistryMatch("9012")),
    stored: JSON.parse(localStorage.getItem(STORAGE.npaRegistry) || "[]"),
    blockedStatus: fakeMember.dataset.status,
    blockedFlag: fakeMember.dataset.npaBlocked,
    decisionDisabled: decisionButtons.every((button) => button.disabled),
    warningHtml: npaAlert?.innerHTML || "",
    approvedCountWithBlockedGuarantor: approvedMembers({ members: [{ status: "Approved", uuid: "999988887777", guarantorAadhaar: "234567890123" }] }).length,
    approvedCountWithoutGuarantorAadhaar: approvedMembers({ members: [{ status: "Approved", uuid: "999988887777", guarantorAadhaar: "" }] }).length,
  };
  loans = [];
  assessOverduePenalties("2026-08-01");
  globalThis.__result.registryAfterAccountRemoval = JSON.parse(JSON.stringify(npaRegistry));
`, context);

assert.equal(context.__result.registry.length, 2, "NPA customer and guarantor should both enter the permanent registry");
assert.equal(context.__result.registry[0].aadhaar, "123456789012", "Aadhaar should be normalized");
assert.equal(context.__result.registry[0].sourceRole, "Customer");
assert.equal(context.__result.registry[1].aadhaar, "234567890123", "Guarantor Aadhaar should be normalized");
assert.equal(context.__result.registry[1].sourceRole, "Guarantor");
assert.equal(context.__result.registry[0].groupNumber, "G99", "NPA provenance should be retained");
assert.equal(context.__result.formattedMatch, true, "Formatted Aadhaar should match the registry");
assert.equal(context.__result.guarantorMatch, true, "NPA guarantor Aadhaar should match the registry");
assert.equal(context.__result.shortNumberMatch, false, "Partial Aadhaar must not match");
assert.equal(context.__result.stored.length, 2, "Customer and guarantor registry should persist in local storage");
assert.equal(context.__result.blockedStatus, "NPA Customer", "Verification member should be marked as NPA");
assert.equal(context.__result.blockedFlag, "true", "Verification member should be data-level blocked");
assert.equal(context.__result.decisionDisabled, true, "Verification decision buttons should be disabled");
assert.match(context.__result.warningHtml, /NPA CUSTOMER/, "Verification should show the NPA warning");
assert.match(context.__result.warningHtml, /Guarantor Aadhaar/, "Verification should identify the blocked guarantor field");
assert.equal(context.__result.approvedCountWithBlockedGuarantor, 0, "Blocked guarantor must remove the applicant from approved loan count");
assert.equal(context.__result.approvedCountWithoutGuarantorAadhaar, 0, "Approval must require both customer and guarantor Aadhaar");
assert.equal(context.__result.registryAfterAccountRemoval.length, 2, "Customer and guarantor blacklist should remain permanent");
assert.match(htmlSource, /class="m-guarantor-aadhaar"/, "Verification should collect guarantor Aadhaar");

console.log("PASS: permanent NPA customer and guarantor Aadhaar blocking");
