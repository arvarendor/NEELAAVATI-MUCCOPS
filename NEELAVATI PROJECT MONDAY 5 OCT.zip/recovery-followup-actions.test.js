const fs = require("fs");
const path = require("path");
const assert = require("assert");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const saveSource = appSource.slice(
  appSource.indexOf("function pendingMemberProposals"),
  appSource.indexOf("function saveInlinePenalty")
);
const renderSource = appSource.slice(
  appSource.indexOf("function renderRecoveryCentre"),
  appSource.indexOf("function openRecoveryCentre")
);

assert.match(saveSource, /pendingMemberProposals\(loan, memberIndex, editProposalId\)/, "A follow-up entry must account for other pending customer proposals");
assert.match(saveSource, /effectiveDemand[\s\S]*snapshot\.demand - pendingRecoveryPayment/, "A pending recovery must reduce the demand used to validate a follow-up advance");
assert.match(saveSource, /projectedPrincipalBalance[\s\S]*snapshot\.principalBalance - pendingPrincipalPayment/, "Follow-up closing must use the projected balance after pending payments");
assert.match(renderSource, /const advanceDisabled = readOnly \|\| closingPending \|\| pendingTypes\.has\("advance"\)/, "A pending recovery must not disable Advance Recovery");
assert.match(renderSource, /const closingDisabled = readOnly \|\| closingPending/, "A pending recovery must not disable Closing");
assert.doesNotMatch(renderSource, /locked = readOnly \|\| Boolean\(pendingProposal\)/, "One pending proposal must not lock every customer action");
assert.match(renderSource, /pendingProposals\.length > 1[\s\S]*PROPOSALS PENDING/, "Multiple pending follow-up entries must be visible to approvers");

console.log("PASS: Recovery receipt keeps Advance Recovery and Closing active with projected validation");
