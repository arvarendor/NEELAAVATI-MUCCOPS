const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const htmlSource = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
function mockElement(initiallyHidden = false) {
  const classes = new Set(initiallyHidden ? ["hidden"] : []);
  const attributes = new Map();
  return {
    textContent: "",
    innerHTML: "",
    classList: {
      toggle(name, force) { if (force) classes.add(name); else classes.delete(name); },
      contains(name) { return classes.has(name); },
    },
    setAttribute(name, value) { attributes.set(name, String(value)); },
    getAttribute(name) { return attributes.get(name); },
    scrollIntoView() {},
  };
}
const monthlyCard = mockElement(true);
const monthlyDetails = mockElement(true);
const elements = new Map([
  ["#pendingCount", { textContent: "" }],
  ["#portfolio", { textContent: "" }],
  ["#allTimeRecovery", { textContent: "" }],
  ["#allTimeRecoveryByDay", { innerHTML: "" }],
  ["#due", { textContent: "" }],
  ["#fieldOfficerCount", { textContent: "" }],
  ["#today", { textContent: "" }],
  ["#monthlyProcessing", { textContent: "" }],
  ["#monthlyProcessingPeriod", { textContent: "" }],
  ["#monthlyProcessingCard", monthlyCard],
  ["#monthlyProcessingDetails", monthlyDetails],
  ["#monthlyProcessingDetailsTitle", { textContent: "" }],
  ["#monthlyProcessingDetailsTotal", { textContent: "" }],
  ["#monthlyProcessingRows", { innerHTML: "" }],
]);
const storage = new Map();
const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: {
    querySelector: (selector) => elements.get(selector) || null,
    querySelectorAll: () => [],
    createElement: () => ({ classList: { add() {}, remove() {} } }),
  },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  todayIso = () => "2026-08-03";
  groups = [
    { code: "GRP-A", number: "G1", name: "A Centre", members: [{ name: "Alice" }, { name: "Bob" }] },
    { code: "GRP-B", number: "G2", name: "B Centre", members: [{ name: "Beena" }] },
    { code: "GRP-D", number: "G4", name: "Future Centre", members: [{ name: "Future Customer" }] },
  ];
  employeeAccounts = [];
  loans = [
    { id: "A", groupCode: "GRP-A", groupNumber: "G1", groupName: "A Centre", disbursedOn: "2026-08-01T09:00:00", day: "Never", balance: 12000, processingFees: 1000, individualLoans: [{ memberIndex: 0, processingFee: 600 }, { memberIndex: 1, processingFee: 400 }] },
    { id: "B", groupCode: "GRP-B", groupNumber: "G2", groupName: "B Centre", disbursedOn: "2026-08-02", day: "Never", balance: 15000, individualLoans: [{ memberIndex: 0, processingFee: 600 }] },
    { id: "C", disbursedOn: "2026-07-31", day: "Never", balance: 20000, processingFees: 900, individualLoans: [] },
    { id: "D", groupCode: "GRP-D", groupNumber: "G4", groupName: "Future Centre", disbursedOn: "2026-08-04", day: "Never", balance: 30000, processingFees: 2000, individualLoans: [{ memberIndex: 0, processingFee: 2000 }] },
  ];
  currentUser = { designation: "Director" };
  renderOverview();
  const directorAmount = document.querySelector("#monthlyProcessing").textContent;
  const directorHidden = document.querySelector("#monthlyProcessingCard").classList.contains("hidden");
  toggleMonthlyProcessingDetails();
  const detailsHidden = document.querySelector("#monthlyProcessingDetails").classList.contains("hidden");
  const detailsHtml = document.querySelector("#monthlyProcessingRows").innerHTML;
  const detailsTotal = document.querySelector("#monthlyProcessingDetailsTotal").textContent;
  currentUser = { designation: "Manager" };
  renderOverview();
  const managerHidden = document.querySelector("#monthlyProcessingCard").classList.contains("hidden");
  currentUser = { designation: "Cashier" };
  renderOverview();
  const cashierHidden = document.querySelector("#monthlyProcessingCard").classList.contains("hidden");
  const cashierDetailsHidden = document.querySelector("#monthlyProcessingDetails").classList.contains("hidden");
  const cashierDetailsHtml = document.querySelector("#monthlyProcessingRows").innerHTML;
  globalThis.__result = { directorAmount, directorHidden, detailsHidden, detailsHtml, detailsTotal, managerHidden, cashierHidden, cashierDetailsHidden, cashierDetailsHtml };
`, context);

assert.equal(context.__result.directorAmount, "₹1,600", "Monthly processing must total only current-month loan processing fees");
assert.equal(context.__result.directorHidden, false, "Director must see Monthly Processing");
assert.equal(context.__result.detailsHidden, false, "Director must be able to open Monthly Processing details");
assert.equal(context.__result.detailsTotal, "₹1,600", "Opened register must show the same current-month total");
assert.match(context.__result.detailsHtml, /G1[\s\S]*Alice[\s\S]*Bob[\s\S]*₹1,000/, "Register must show group and customer-wise processing details");
assert.match(context.__result.detailsHtml, /G2[\s\S]*Beena[\s\S]*₹600/, "Register must show every processed group up to today");
assert.doesNotMatch(context.__result.detailsHtml, /Future Centre|G4/, "Future processing must not appear in today's register");
assert.equal(context.__result.managerHidden, false, "Manager must see Monthly Processing");
assert.equal(context.__result.cashierHidden, true, "Other roles must not see Monthly Processing");
assert.equal(context.__result.cashierDetailsHidden, true, "Other roles must not open Monthly Processing details");
assert.equal(context.__result.cashierDetailsHtml, "", "Other roles must not receive Monthly Processing detail rows");
assert.ok(htmlSource.indexOf('id="due"') < htmlSource.indexOf('id="monthlyProcessingCard"'), "Monthly Processing must appear beside and after Collection due today");

console.log("PASS: current-month processing total, dashboard placement, and Director/Manager-only visibility");
