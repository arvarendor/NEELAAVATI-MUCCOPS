const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
const storage = new Map();
const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: { querySelector: () => null, querySelectorAll: () => [] },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  employeeAccounts = [
    { name: "Brijesh Wankhede", loginId: "brijesh", designation: "Staff", active: true },
    { name: "Vijay Field", loginId: "vijay", designation: "Staff", active: true },
  ];
  groups = [
    { code: "GRP-1", number: "G1", name: "First Centre", members: [{ name: "Customer One" }, { name: "Customer Three" }] },
    { code: "GRP-2", number: "G2", name: "Second Centre", members: [{ name: "Customer Two" }] },
  ];
  loans = [
    {
      id: "LOAN-1", groupCode: "GRP-1", groupNumber: "G1", groupName: "First Centre", amount: 12000,
      disbursedOn: "2026-08-20", day: "Saturday",
      individualLoans: [
        { memberIndex: 0, amount: 12000, holdAmount: 0, closedAt: "2026-08-22" },
        { memberIndex: 1, amount: 12000, holdAmount: 0, closedAt: "2026-08-22" },
      ],
      recoveries: [{
        id: "REC-1", type: "recovery", date: "2026-08-22", amount: 1000, principalPaid: 950, penaltyPaid: 50,
        member: 0, allocations: [{ memberIndex: 0, amount: 1000 }], enteredBy: "brijesh",
        approvedBy: "cashier-1", approvedByName: "Cashier One", receipt: "R-1",
      }, {
        id: "REC-1B", type: "recovery", date: "2026-08-22", amount: 500, principalPaid: 500, penaltyPaid: 0,
        member: 1, allocations: [{ memberIndex: 1, amount: 500 }], enteredBy: "brijesh", receipt: "R-1B",
      }],
    },
    {
      id: "LOAN-2", groupCode: "GRP-2", groupNumber: "G2", groupName: "Second Centre", amount: 15000,
      disbursedOn: "2026-08-20", day: "Saturday",
      individualLoans: [{ memberIndex: 0, amount: 15000, holdAmount: 0, closedAt: "2026-08-22" }],
      recoveries: [{
        id: "REC-2", type: "advance", date: "2026-08-22", amount: 700, principalPaid: 700, penaltyPaid: 0,
        member: 0, allocations: [{ memberIndex: 0, amount: 700 }], enteredBy: "brijesh", receipt: "R-2",
      }, {
        id: "REC-3", type: "closing", date: "2026-08-22", amount: 5000, principalPaid: 5000, penaltyPaid: 0,
        member: 0, allocations: [{ memberIndex: 0, amount: 5000 }], enteredByName: "Vijay Field", enteredBy: "vijay", enteredByRole: "Staff",
      }],
    },
  ];
  const entries = automaticCashbookEntries("2026-08-22").filter((entry) => STAFF_COLLECTION_SOURCES.has(entry.source));
  const recoveryCategoryEntries = entries.filter((entry) => daybookCategoryForEntry(entry) === "total-recovery");
  const compactRecoveryEntries = compactCashbookCategoryEntries(recoveryCategoryEntries, { key: "total-recovery" });
  globalThis.__result = {
    entries,
    register: staffCollectionRegisterHtml(entries),
    compactRecoveryEntries,
  };
`, context);

const brijeshEntries = context.__result.entries.filter((entry) => entry.collectionStaffName === "Brijesh Wankhede");
assert.equal(brijeshEntries.length, 4, "Recoveries, penalty, and advance recovery must retain the collecting staff name");
assert.equal(brijeshEntries.reduce((sum, entry) => sum + entry.amount, 0), 2200, "Staff total must equal all money collected by that staff member");
assert.ok(brijeshEntries.every((entry) => entry.createdBy === "Brijesh Wankhede"), "Cashbook created-by must be the collecting staff, not the approver");
assert.equal(brijeshEntries[0].approvedBy, "Cashier One", "Cashier approval must remain separate audit metadata");
assert.match(context.__result.register, /STAFF COLLECTION/, "Daybook must show the Staff Collection register");
assert.match(context.__result.register, /Brijesh Wankhede[\s\S]*₹2,200/, "Staff name must show above the staff collection total");
assert.match(context.__result.register, /G1 · First Centre[\s\S]*₹1,500/, "All customers from the first centre must appear as one group total");
assert.match(context.__result.register, /G2 · Second Centre/, "The second updated centre must appear below the same staff name");
assert.match(context.__result.register, /Vijay Field[\s\S]*₹5,000/, "Closing must be grouped under the collecting employee");
assert.equal(context.__result.compactRecoveryEntries.length, 1, "Customer-wise recovery rows from the same group and staff must collapse to one row");
assert.equal(context.__result.compactRecoveryEntries[0].amount, 1450, "The compact group recovery row must preserve the exact category total");
assert.match(context.__result.compactRecoveryEntries[0].description, /G1 · First Centre/, "Compact Cashbook rows must use group and centre details");
assert.match(context.__result.compactRecoveryEntries[0].reference, /2 customer entries/, "Compact Cashbook rows must state how many customer entries were combined");
assert.doesNotMatch(context.__result.register, /Customer One|Customer Three/, "Staff Collection register must not create a long customer-by-customer list");
assert.match(context.__result.register, /<details class="staff-collection-card">/, "Staff centre details must be collapsible to save Daybook space");
assert.match(appSource, /enteredByName: proposal\.proposedBy/, "Approved staff proposals must preserve the staff display name");
assert.match(appSource, /enteredByName: currentUser\?\.name/, "Direct recovery entries must preserve the employee display name");

console.log("PASS: staff-wise Recovery, Advance, Closing, Penalty, and centre breakdown in Cashbook");
