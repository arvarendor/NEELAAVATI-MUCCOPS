const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const htmlSource = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));

const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: { getItem: () => null, setItem() {}, removeItem() {} },
  document: { querySelector: () => null, querySelectorAll: () => [] },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  loans = [
    {
      balance: 99999,
      individualLoans: [
        { amount: 12000, balance: 7000, penaltyBalance: 100, emi: 600 },
        { amount: 15000, balance: 9000, penaltyBalance: 0, emi: 700 },
      ],
      day: "Monday",
    },
    {
      balance: 4500,
      emi: 500,
      day: "Tuesday",
    },
  ];
  const market = currentMarketOutstandingTotal();
  loans = Array.from({ length: 100 }, (_, index) => ({
    id: "MON-" + (index + 1),
    day: "Monday",
    emi: 3500,
    balance: 50000,
    recoveries: [{ type: "advance", amount: 99999 }],
  }));
  loans.push({ id: "TUE-ACTIVE", day: "Tuesday", emi: 2800, balance: 20000 });
  loans.push({ id: "TUE-CLOSED", day: "Tuesday", emi: 2800, balance: 0 });
  const byDay = weeklyRecoveryTotalsByDay();
  globalThis.__result = {
    market,
    recovered: allTimeRecoveryTotal(byDay),
    byDay,
  };
`, context);

assert.equal(context.__result.market, 20600, "Market outstanding must use current customer balances plus pending penalties and support legacy loan balances");
assert.equal(context.__result.recovered, 352800, "All-days total must add every active centre's single weekly recovery");
assert.deepEqual(JSON.parse(JSON.stringify(context.__result.byDay.Monday)), { centres: 100, amount: 350000 }, "100 Monday centres at ₹3,500 each must show ₹3,50,000");
assert.deepEqual(JSON.parse(JSON.stringify(context.__result.byDay.Tuesday)), { centres: 1, amount: 2800 }, "Closed centres must not be counted in a weekday total");
assert.deepEqual(JSON.parse(JSON.stringify(context.__result.byDay.Wednesday)), { centres: 0, amount: 0 }, "Days without active centres must stay at zero");
assert.equal(context.__result.byDay.Monday.amount, 100 * 3500, "Monday total must equal active centre count multiplied by each centre's single recovery");
assert.match(htmlSource, /Current market outstanding[\s\S]*id="portfolio"/, "Operation Desk must label the outstanding market amount clearly");
assert.match(htmlSource, /Weekly recovery · All days[\s\S]*id="allTimeRecovery"[\s\S]*id="allTimeRecoveryByDay"/, "Operation Desk must show cumulative and day-wise weekly recovery");

console.log("PASS: Operation Desk active-centre count and single weekly recovery totals by day");
