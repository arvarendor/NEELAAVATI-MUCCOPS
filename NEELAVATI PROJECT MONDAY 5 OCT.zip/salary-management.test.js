const fs = require("fs");
const assert = require("assert");
const path = require("path");

const html = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const app = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const server = fs.readFileSync(path.join(__dirname, "server", "server.mjs"), "utf8");

assert.match(html, /data-page="employees"[\s\S]*Employee Management/, "Employee Access must be renamed Employee Management");
assert.match(html, /data-employee-view="login"[\s\S]*data-employee-view="salary"/, "Employee Management must contain Employee Login and Salary Management views");
assert.match(html, /id="salaryEmployeeCount"[\s\S]*id="salaryPayrollTotal"/, "Salary summary must show employee and payroll totals");
assert.match(html, /id="salaryRows"/, "Salary Management must include the staff-wise register");
assert.doesNotMatch(html, /data-page="salary"/, "Salary Management must no longer be a separate core page");
assert.match(app, /validViews = \["login", "salary", "working", "attendance", "salary-book", "recurring-deposit"\]/, "Employee Management must contain all six requested workspaces");
assert.match(app, /nextView !== "login" && role\(\) !== "Director"/, "Only the Director may open Salary, My Working and Staff Attendance views");
assert.match(app, /function renderSalaryManagement\(\)/, "Salary Management must render from saved employee records");
assert.match(app, /function employeeTeamFolders\(\)[\s\S]*designation === "Assistant Manager"[\s\S]*assistantManagerLoginId/, "Employee records must be grouped under their assigned Assistant Manager");
assert.match(app, /renderEmployeeTeamFolders\("salary"/, "Salary Management must open through Assistant Manager folders");
assert.match(app, /view === "salary"[\s\S]*allFolders\.filter\(\(folder\) => Boolean\(folder\.assistant\)\)/, "Salary Management folder list must show Assistant Managers only");
assert.match(app, /renderEmployeeTeamFolders\("working"/, "Director My Working must open through Assistant Manager folders");
assert.match(app, /renderEmployeeTeamFolders\("attendance"/, "Staff Attendance must open through Assistant Manager folders");
assert.match(app, /employeeMonthlyPayroll\(account\)/, "Net salary after allowances and RD must be totalled separately from incentive");
assert.match(app, /const active = employeeAccounts\.filter\(\(account\) => account\.active !== false\)/, "Team folders must include active employees");
assert.match(server, /store\.listUsers\(session\.user\.designation === "Director"\)/, "Secure server must expose compensation only to a Director");

console.log("PASS: Employee Management combines logins with Director-only salary records");
