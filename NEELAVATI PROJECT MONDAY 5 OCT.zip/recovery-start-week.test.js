const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const htmlSource = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
const storage = new Map();
const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: { querySelector: () => null, querySelectorAll: () => [] },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  bankHolidays = [];
  const disbursedWednesday = "2026-08-19T12:00:00";
  const currentFriday = scheduleRows(1, disbursedWednesday, "Friday", "current");
  const nextFriday = scheduleRows(1, disbursedWednesday, "Friday", "next");
  const currentWednesday = scheduleRows(1, disbursedWednesday, "Wednesday", "current");
  const nextWednesday = scheduleRows(1, disbursedWednesday, "Wednesday", "next");
  const legacyWednesday = scheduleRows(1, disbursedWednesday, "Wednesday", "legacy");
  const exactHistoricalMonday = scheduleRows(2, disbursedWednesday, "Monday", "date:2026-07-06");
  bankHolidays = [{ date: "2026-08-21", name: "Bank Holiday" }];
  const holidaySchedule = scheduleRows(1, disbursedWednesday, "Friday", "current");
  globalThis.__result = {
    currentFriday,
    nextFriday,
    currentWednesday,
    nextWednesday,
    legacyWednesday,
    holidaySchedule,
    savedCurrentMode: loanRecoveryStartMode({ recoveryStartWeek: "current" }),
    savedNextMode: loanRecoveryStartMode({ recoveryStartWeek: "next" }),
    savedCustomMode: loanRecoveryStartMode({ recoveryStartWeek: "custom", firstRecoveryDate: "2026-07-06" }),
    oldLoanMode: loanRecoveryStartMode({}),
    customEditSelection: recoveryStartSelectionForEdit({ recoveryStartWeek: "custom", firstRecoveryDate: "2026-07-06" }),
    oldSameDayEditSelection: recoveryStartSelectionForEdit({ disbursedOn: disbursedWednesday, day: "Wednesday" }),
    oldFridayEditSelection: recoveryStartSelectionForEdit({ disbursedOn: disbursedWednesday, day: "Friday" }),
    exactHistoricalMonday,
  };
`, context);

const firstInstallmentDate = (rows) => rows.find((row) => row.type === "installment")?.date;
assert.equal(firstInstallmentDate(context.__result.currentFriday), "2026-08-21", "Current week must use the selected day in the current week");
assert.equal(firstInstallmentDate(context.__result.nextFriday), "2026-08-28", "Next week must move the selected day forward by one week");
assert.equal(firstInstallmentDate(context.__result.currentWednesday), "2026-08-19", "Current week may start on the disbursement day when the days match");
assert.equal(firstInstallmentDate(context.__result.nextWednesday), "2026-08-26", "Next week must start seven days later when the days match");
assert.equal(firstInstallmentDate(context.__result.legacyWednesday), "2026-08-26", "Old loan records must preserve the previous same-day schedule behavior");
assert.equal(firstInstallmentDate(context.__result.exactHistoricalMonday), "2026-07-06", "Director-selected historical schedule must start on the exact previous date");
assert.equal(context.__result.exactHistoricalMonday[1].date, "2026-07-13", "Historical schedule must continue weekly from the exact date");
assert.equal(context.__result.holidaySchedule[0].type, "holiday", "A holiday on the chosen first date must remain visible");
assert.equal(context.__result.holidaySchedule[0].name, "Bank Holiday", "Holiday name must be retained in the schedule");
assert.equal(firstInstallmentDate(context.__result.holidaySchedule), "2026-08-28", "Holiday must extend the first EMI to the next valid week");
assert.equal(context.__result.savedCurrentMode, "current");
assert.equal(context.__result.savedNextMode, "next");
assert.equal(context.__result.savedCustomMode, "date:2026-07-06");
assert.equal(context.__result.customEditSelection, "custom");
assert.equal(context.__result.oldLoanMode, "legacy", "Existing loans without the new field must remain backward compatible");
assert.equal(context.__result.oldSameDayEditSelection, "next", "Editing an old same-day loan must preserve its schedule");
assert.equal(context.__result.oldFridayEditSelection, "current", "Editing an old upcoming-day loan must preserve its schedule");
assert.match(htmlSource, /id="loanRecoveryStart"[\s\S]*value="current"[\s\S]*value="next"[\s\S]*value="custom"/, "Loan form must offer Current week, Next week, and Director exact-date choices");
assert.match(htmlSource, /id="loanFirstRecoveryDate"[^>]*readonly/, "Loan form must preview the calculated first recovery date");
assert.match(appSource, /recoveryStartWeek: recoveryStartChoice === "custom"/, "Disbursement must save the selected recovery start mode");
assert.match(appSource, /loanRecoveryStartMode\(loan\)/, "Loan schedules must use the saved start-week selection");

console.log("PASS: Current/Next week selection, first recovery preview, holidays, persistence, and legacy compatibility");
