const fs = require("fs");
const assert = require("assert");
const path = require("path");

const html = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const app = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const css = fs.readFileSync(path.join(__dirname, "style.css"), "utf8");

assert.match(html, /data-page="team-target"[\s\S]*Team Monthly Target/, "Assistant Manager must have a Team Monthly Target core feature");
assert.match(html, /id="teamTargetMonth"[\s\S]*id="teamTargetStaffList"/, "Monthly Target must provide a month filter and Staff-wise list");
assert.match(app, /"Assistant Manager": \["verification", "recovery", "working", "team-target"\]/, "Assistant Manager must receive target and Recovery Demand access");
assert.match(app, /function renderTeamMonthlyTarget\(\)[\s\S]*assignedTeamStaff\(assistant\)/, "Monthly Target must use only Staff assigned to the signed-in Assistant Manager");
assert.match(app, /function teamTargetFileStatus\(group\)[\s\S]*key: "disbursed"[\s\S]*key: "unverified"/, "Target files must distinguish disbursed and unverified states");
assert.match(css, /team-target-file\.is-disbursed[\s\S]*team-target-file\.is-unverified/, "Disbursed and unverified files must have green and red visual states");
assert.match(app, /function assistantManagerRecoveryStaffNames\(\)[\s\S]*assignedTeamStaff\(currentUser\)/, "Recovery Demand must resolve only the Assistant Manager's assigned Staff");
assert.match(app, /function canViewRecoveryLoan\(loan\)[\s\S]*assistantManagerRecoveryStaffNames\(\)\.includes\(loan\?\.staff\)/, "Assistant Manager must not see recovery loans outside the assigned team");
assert.match(app, /const staffTodayOnly = canProposeRecovery\(\)/, "Only Staff must be locked to today's demand; Assistant Manager can redistribute centres across weekdays");
assert.match(app, /createdAt: previous\?\.createdAt \|\| new Date\(\)\.toISOString\(\)/, "Verification files must keep a stable creation month for target reporting");

console.log("PASS: Assistant Manager monthly targets and assigned-team recovery demand are scoped correctly");
