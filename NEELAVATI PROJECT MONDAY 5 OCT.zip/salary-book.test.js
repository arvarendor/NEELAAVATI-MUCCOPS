const fs = require("fs");
const assert = require("assert");
const path = require("path");
const vm = require("vm");

const app = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const style = fs.readFileSync(path.join(__dirname, "style.css"), "utf8");

assert.match(app, /data-employee-view="salary-book"[\s\S]*Salary Book/, "Employee Management must add a Salary Book box");
assert.match(app, /id="employeeSalaryBookView"[\s\S]*id="salaryBookMonth" type="month"/, "Salary Book must provide a month selector");
assert.match(app, /ATTENDANCE_SALARY_ROLES = \["Manager", "Assistant Manager", "Cashier", "Executive", "Staff"\]/, "Salary Book must cover every requested employee role and exclude Director");
assert.match(app, /function salaryBookLeaveStatement\(account, month = salaryBookMonth\)/, "Salary Book must calculate carried leave balances");
assert.match(app, /const credited = Math\.max\(0, selectedSerial - startSerial \+ 1\)/, "Employees must earn exactly one leave per eligible month without annual advance credit");
assert.doesNotMatch(app, /Math\.min\(12,[^)]*selectedMonthNumber/, "Monthly leave must not be capped or pre-credited as an annual block");
assert.match(app, /record\.status === "Absent"[\s\S]*const used = absentDates\.size/, "Absent attendance must consume a leave once per date");
assert.match(app, /balance: Math\.max\(0, credited - used\)/, "Unused leaves must carry forward as the visible balance");
assert.match(app, /id="salaryBookPayrollTotal"[\s\S]*id="salaryBookLeaveBalance"/, "Salary Book must summarize monthly payroll and remaining leave");
assert.match(app, /if \(role\(\) !== "Director"\)[\s\S]*rows\.innerHTML = ""/, "Salary Book data must be Director-only");
assert.match(app, /createdAt: new Date\(\)\.toISOString\(\)/, "New local employee accounts must retain their leave-accrual start month");
assert.match(style, /employee-management-tabs\{grid-template-columns:repeat\(6,minmax\(170px,1fr\)\)!important\}/, "Employee Management must lay out all six feature boxes");

const leaveHelpers = app.slice(app.indexOf("function validYearMonth"), app.indexOf("function renderSalaryBook"));
const context = {
  salaryBookMonth: "2026-03",
  workingRecords: [],
  result: null,
};
vm.createContext(context);
vm.runInContext(`${leaveHelpers}\nresult = salaryBookLeaveStatement({ loginId: "staff-1", createdAt: "2026-01-10T00:00:00Z" }, "2026-03");`, context);
assert.deepStrictEqual(JSON.parse(JSON.stringify(context.result)), { credited: 3, used: 0, balance: 3, startMonth: "2026-01" }, "Three unused monthly leaves must accumulate to a balance of three");

context.workingRecords = [
  { kind: "attendance", employeeLoginId: "staff-1", date: "2026-02-12", status: "Absent" },
  { kind: "attendance", employeeLoginId: "staff-1", date: "2026-02-12", status: "Absent" },
];
vm.runInContext('result = salaryBookLeaveStatement({ loginId: "staff-1", createdAt: "2026-01-10T00:00:00Z" }, "2026-03");', context);
assert.deepStrictEqual(JSON.parse(JSON.stringify(context.result)), { credited: 3, used: 1, balance: 2, startMonth: "2026-01" }, "One absent date must use one carried leave without double-counting duplicates");

context.workingRecords = [];
vm.runInContext('result = salaryBookLeaveStatement({ loginId: "staff-1", createdAt: "2025-11-10T00:00:00Z" }, "2026-02");', context);
assert.deepStrictEqual(JSON.parse(JSON.stringify(context.result)), { credited: 4, used: 0, balance: 4, startMonth: "2025-11" }, "Unused monthly leave must continue accumulating across the year boundary as 1, 2, 3, 4");

console.log("PASS: Director Salary Book shows month-wise payroll and carried free-leave balances");
