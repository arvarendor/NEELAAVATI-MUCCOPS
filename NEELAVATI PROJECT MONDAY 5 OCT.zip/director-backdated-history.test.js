const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const htmlSource = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
const storage = new Map();
const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: { querySelector: () => null, querySelectorAll: () => [] },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  bankHolidays = [];
  currentUser = { name: "Shubham", loginId: "shubham", designation: "Director" };
  const directorCanBackdate = canBackdateOperationalEntries();
  currentUser = { name: "Manager", loginId: "manager", designation: "Manager" };
  const managerCanBackdate = canBackdateOperationalEntries();
  const historicalLoan = {
    recoveryStartWeek: "custom",
    firstRecoveryDate: "2026-07-06",
    disbursedOn: "2026-06-29",
    day: "Monday",
    historyImportPending: true,
  };
  const individual = { amount: 12000, balance: 12000, emi: 600, term: 26 };
  const pausedOverdue = memberOverdueInfo(historicalLoan, individual, "2026-08-24");
  historicalLoan.historyImportPending = false;
  const liveOverdue = memberOverdueInfo(historicalLoan, individual, "2026-08-24");
  globalThis.__result = { directorCanBackdate, managerCanBackdate, pausedOverdue, liveOverdue };
`, context);

assert.equal(context.__result.directorCanBackdate, true, "Director must be able to use previous operational dates");
assert.equal(context.__result.managerCanBackdate, false, "Manager must remain restricted to today's operational date");
assert.equal(context.__result.pausedOverdue.overdue, false, "Penalty and NPA must pause while old recovery and hold history is being entered");
assert.equal(context.__result.liveOverdue.overdue, true, "Normal overdue calculation must resume after Director finishes old entries");
assert.match(htmlSource, /value="custom">Previous \/ exact date · Director/, "Loan form must expose Director exact-date mode");
assert.match(htmlSource, /id="entryDate"[^>]*readonly/, "Recovery date must remain locked by default for non-Director logins");
assert.match(htmlSource, /id="holdDate"[^>]*readonly/, "Hold date must remain locked by default for non-Director logins");
assert.match(htmlSource, /id="loanSanctionDate"[^>]*readonly/, "Loan sanction date must be editable only in Director old-data mode");
assert.match(appSource, /directorRecoveryEntryDate\(loanIndex\)/, "Director inline recovery must use the selected previous entry date");
assert.match(appSource, /date: holdEntryDate/, "Previous Hold Loan entry must save the Director-selected date");
assert.match(appSource, /disbursedOn: selectedSanctionDate \?/, "Old loan must save the original Director-selected disbursement date");
assert.match(appSource, /Finish old entries/, "Loan Record must provide a clear action to complete historical entry mode");
assert.match(appSource, /historyImportPending = false/, "Finishing old entries must resume live loan calculations");
assert.match(appSource, /Previous recovery entry · Director[\s\S]*id="loanHistoryRecoveryPanel"/, "Loan Record Group Folder must show a Director previous-recovery workspace");
assert.match(appSource, /function setLoanHistoryRecoveryDate[\s\S]*directorRecoveryEntryDates\.set\(Number\(loanIndex\), selected\)/, "Director must be able to select the exact previous recovery date inside the Group Folder");
assert.match(appSource, /function saveHistoricalRecovery[\s\S]*Only the Director can enter previous recovery from Loan Record[\s\S]*form\.dataset\.demandDate = entryDate[\s\S]*saveRecoveryEntry\(\)/, "Previous Group Folder recovery must use the selected date and the normal balance-updating save flow");
assert.match(appSource, /data-history-type="\$\{type\}"/, "Every historical customer row must expose Recovery, Advance and Closing amount inputs");
assert.match(appSource, /Recovery recorded[\s\S]*Balance after entries/, "Group Folder must show recorded recovery and the resulting customer balance");
assert.doesNotMatch(htmlSource, /data-page="olddata"|id="olddata"|Old Data Import/i, "The previous Old Data Import option and page must be removed");
assert.doesNotMatch(appSource.slice(0, appSource.indexOf("const PAGE_TITLES")), /"olddata"/, "Director navigation access must no longer include Old Data Import");

console.log("PASS: Director backdated workflow remains available without the previous Old Data Import option");
