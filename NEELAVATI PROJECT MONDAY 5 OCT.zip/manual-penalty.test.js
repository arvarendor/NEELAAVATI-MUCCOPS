const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const htmlSource = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
const storage = new Map();
const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: {
    querySelector: () => null,
    querySelectorAll: () => [],
    createElement: () => ({ className: "", remove() {}, classList: { add() {}, remove() {} } }),
  },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  groups = [{ code: "GRP-1", number: "G1", name: "Penalty Centre", members: [{ name: "Asha" }] }];
  loans = [{
    id: "LOAN-1",
    groupCode: "GRP-1",
    groupNumber: "G1",
    individualLoans: [{ memberIndex: 0, amount: 10000, balance: 10000, emi: 1000, term: 26, penaltyBalance: 0, penaltyAccrued: 0, penaltyHistory: [] }],
  }];
  registerNpaCustomer = () => false;
  persistAll = () => true;
  memberOverdueInfo = (loan, individual, asOf) => {
    const days = calendarDaysBetween("2026-06-01", asOf);
    return { overdue: days > 0, days, dueDate: "2026-06-01", npa: days >= 30 };
  };

  assessOverduePenalties("2026-06-10");
  const beforeNpa = JSON.parse(JSON.stringify(loans[0].individualLoans[0]));
  assessOverduePenalties("2026-07-01");
  const firstNpaDay = JSON.parse(JSON.stringify(loans[0].individualLoans[0]));
  assessOverduePenalties("2026-07-02");
  assessOverduePenalties("2026-07-02");
  const secondNpaDay = JSON.parse(JSON.stringify(loans[0].individualLoans[0]));

  const normal = { amount: 12000, balance: 12000, penaltyBalance: 200, penaltyAccrued: 200, penaltyHistory: [] };
  const normalBreakdown = applyCustomerRecoveryPayment(normal, 1000, "recovery", "Staff");
  const normalDemand = memberDemandSnapshot(
    { disbursedOn: "2026-08-19T12:00:00", day: "Wednesday", term: 26, recoveryStartWeek: "current" },
    { ...normal, emi: 1000, term: 26 },
    "2026-08-26"
  );

  const closing = { amount: 5000, balance: 5000, penaltyBalance: 0, penaltyAccrued: 0, penaltyHistory: [] };
  const closingRecovery = { id: "REC-CLOSE", type: "closing", date: "2026-08-26" };
  assessManualPenalty(closing, closingRecovery, 300, "Staff");
  const closingBreakdown = applyCustomerRecoveryPayment(closing, 5300, "closing", "Staff");

  globalThis.__result = {
    beforeNpa,
    firstNpaDay,
    secondNpaDay,
    normal,
    normalBreakdown,
    normalDemand,
    closing,
    closingBreakdown,
  };
`, context);

assert.equal(context.__result.beforeNpa.penaltyBalance, 0, "Automatic penalty must remain off before the customer reaches NPA");
assert.equal(context.__result.beforeNpa.penaltyHistory.length, 0, "No pre-NPA automatic penalty history may be created");
assert.equal(context.__result.firstNpaDay.penaltyBalance, 50, "Automatic ₹50 penalty must start on the first NPA day");
assert.equal(context.__result.firstNpaDay.penaltyHistory[0].source, "npa-auto", "NPA automatic penalty must have an auditable source");
assert.equal(context.__result.secondNpaDay.penaltyBalance, 100, "Automatic penalty must add ₹50 for each day after NPA begins");
assert.equal(context.__result.secondNpaDay.penaltyHistory.length, 2, "Repeated assessment on the same date must not duplicate NPA penalty");

assert.equal(context.__result.normalBreakdown.principalPaid, 1000, "Normal recovery must still reduce principal by the entered recovery amount");
assert.equal(context.__result.normalBreakdown.penaltyPaid, 0, "Normal recovery must never pay or adjust penalty");
assert.equal(context.__result.normal.balance, 11000, "Manual penalty must not reduce the principal recovery allocation");
assert.equal(context.__result.normal.penaltyBalance, 200, "Manual penalty must be added to the customer's closing balance");
assert.equal(context.__result.normal.penaltyAccrued, 200, "Manual penalty must be recorded in accrued penalty");
assert.equal(context.__result.normalDemand.demand, 1000, "Penalty must not increase the weekly EMI recovery demand");
assert.equal(context.__result.normalDemand.balance, 11200, "Penalty must remain included in the loan closing balance");

assert.equal(context.__result.closingBreakdown.penaltyPaid, 300, "Closing payment must include the newly entered manual penalty");
assert.equal(context.__result.closing.balance, 0, "Full closing payment must clear principal");
assert.equal(context.__result.closing.penaltyBalance, 0, "Full closing payment must clear manual penalty");
assert.ok(context.__result.closing.closedAt, "Customer must close only after principal and manual penalty are cleared");
assert.match(appSource, /data-inline-penalty/, "Recovery Demand must show the manual Penalty box beside inline recovery actions");
assert.match(appSource, /onclick="saveInlinePenalty\(/, "The inline Penalty box must have its own Update button");
assert.match(appSource, /Closing increases · EMI recovery unchanged/, "The inline Penalty box must explain that recovery remains unchanged");
assert.match(htmlSource, /id="entryPenalty" type="hidden"/, "Recovery and closing forms must not silently combine a penalty with payment");
assert.match(appSource, /addCalendarDays\(overdue\.dueDate, 30\)/, "Automatic penalty must start only at the NPA threshold");

console.log("PASS: separate Penalty Update increases closing while EMI recovery stays unchanged");
