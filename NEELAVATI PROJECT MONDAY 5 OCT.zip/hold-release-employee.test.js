const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
const storage = new Map();
const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: { querySelector: () => null, querySelectorAll: () => [] },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  currentUser = { name: "Brijesh Wankhede", loginId: "brijesh", designation: "Staff" };
  const staffCanEnter = canEnterHoldLoan();
  currentUser = { name: "Cashier One", loginId: "cashier-1", designation: "Cashier" };
  const cashierCanEnter = canEnterHoldLoan();
  currentUser = { name: "Assistant One", loginId: "assistant-1", designation: "Assistant Manager" };
  const assistantCanEnter = canEnterHoldLoan();

  groups = [{ code: "GRP-1", number: "G1", name: "Test Centre", members: [{ name: "Customer One" }] }];
  loans = [{
    id: "LOAN-1",
    groupCode: "GRP-1",
    groupNumber: "G1",
    groupName: "Test Centre",
    amount: 12000,
    disbursedOn: "2026-08-22",
    individualLoans: [{
      memberIndex: 0,
      amount: 12000,
      holdAmount: 2000,
      closedAt: "2026-08-22",
      holdTransactions: [{
        id: "HOLD-1",
        date: "2026-08-22",
        amount: 750,
        note: "First release",
        releasedByName: "Brijesh Wankhede",
        releasedByLoginId: "brijesh",
        releasedByRole: "Staff",
      }],
    }],
  }];
  const holdCashbook = automaticCashbookEntries("2026-08-22").find((entry) => entry.source === "hold-release");
  globalThis.__result = { staffCanEnter, cashierCanEnter, assistantCanEnter, holdCashbook };
`, context);

assert.equal(context.__result.staffCanEnter, true, "Staff login must be able to access and enter Hold Loan releases");
assert.equal(context.__result.cashierCanEnter, true, "Cashier must retain Hold Loan access");
assert.equal(context.__result.assistantCanEnter, false, "Assistant Manager must retain verification-only operational access");
assert.equal(context.__result.holdCashbook.amount, 750, "Cashbook must carry the released hold amount");
assert.equal(context.__result.holdCashbook.holdReleasedBy, "Brijesh Wankhede", "Cashbook must identify the employee who released the hold amount");
assert.equal(context.__result.holdCashbook.holdReleasedByLoginId, "brijesh", "Cashbook must retain the employee login ID for audit");
assert.equal(context.__result.holdCashbook.createdByRole, "Staff", "Cashbook must retain the employee designation");
assert.match(context.__result.holdCashbook.description, /By Brijesh Wankhede/, "Employee name must be visible in the Cashbook description");
assert.equal(context.__result.holdCashbook.daybookCategory, "hold-loan-deduction", "Release must appear under Hold Loan Deduction");
assert.match(appSource, /releasedByName: existingTransaction\?\.releasedByName/, "New hold entries must store the releasing employee");
assert.match(appSource, /Released by \$\{escapeHtml\(holdReleaseEmployeeName\(entry\)\)\}/, "Hold Loan history must show the releasing employee");

console.log("PASS: employee hold access, release attribution, and Cashbook posting");
