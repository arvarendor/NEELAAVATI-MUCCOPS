const fs = require("fs");
const path = require("path");
const assert = require("assert");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const htmlSource = fs.readFileSync(path.join(__dirname, "index.html"), "utf8");
const cssSource = fs.readFileSync(path.join(__dirname, "style.css"), "utf8");
const renderSource = appSource.slice(
  appSource.indexOf("function proposalStaffKey"),
  appSource.indexOf("function updateClosingAuthorization")
);
const batchSource = appSource.slice(
  appSource.indexOf("function approveRecoveryProposalGroup"),
  appSource.indexOf("function memberHasRecovery")
);
const recoveryPageSource = htmlSource.slice(
  htmlSource.indexOf('<section id="recovery"'),
  htmlSource.indexOf('<section id="approvals"')
);
const approvalPageSource = htmlSource.slice(
  htmlSource.indexOf('<section id="approvals"'),
  htmlSource.indexOf('<section id="hold"')
);

assert.match(renderSource, /const staffSections = new Map\(\)/, "Approval entries must be grouped by staff");
assert.match(renderSource, /groups: new Map\(\)/, "Each staff section must group entries by centre/group");
assert.match(renderSource, /proposal-staff-head[\s\S]*STAFF/, "Staff name must appear as the approval section heading");
assert.match(renderSource, /proposal-group-head[\s\S]*GROUP/, "Member entries must appear below their group heading");
assert.match(renderSource, /approveRecoveryProposalGroup\(/, "Approval UI must provide one group-level approval action");
assert.doesNotMatch(renderSource, /onclick="approveRecoveryProposal\(/, "Individual member Approve buttons must be removed");
assert.match(batchSource, /filter\(\(proposal\) => proposal\.status === "Pending" && proposalStaffKey\(proposal\) === staffKey\)/, "Group approval must include every pending entry from that staff in the selected group");
assert.match(batchSource, /for \(const proposal of pending\)/, "Group approval must process all member entries");
assert.match(batchSource, /loans\[loanIndex\] = loanBackup/, "A failed member validation must roll back the whole group approval");
assert.match(appSource, /window\.approveRecoveryProposalGroup = approveRecoveryProposalGroup/, "Group approval must be callable from the interface");
assert.match(htmlSource, /data-page="approvals"[^>]*>[\s\S]*?Staff Entry Approvals/, "Sidebar must contain the separate Staff Entry Approvals core feature");
assert.match(htmlSource, /data-go="approvals"/, "Operations Desk core features must link to Staff Entry Approvals");
assert.doesNotMatch(recoveryPageSource, /recoveryApprovalQueue|Staff-wise group approvals/, "Recovery Demand must not contain the staff approval queue");
assert.match(approvalPageSource, /id="recoveryApprovalQueue"[\s\S]*Staff-wise group approvals/, "Staff approvals must render on their own page");
assert.match(approvalPageSource, /id="staffCollectionApprovalRegister"/, "Staff Collection window must appear on the Staff Entry Approvals page");
assert.match(renderSource, /renderStaffCollectionApprovalRegister\(\)/, "Opening Staff Entry Approvals must refresh Staff Collection");
assert.match(appSource, /function renderStaffCollectionApprovalRegister\(\)[\s\S]*host\.innerHTML = staffCollectionRegisterHtml\(entries\)/, "Staff Collection must render inside its approval-page host");
const daybookColumnSource = appSource.slice(
  appSource.indexOf("function daybookColumnHtml"),
  appSource.indexOf("function renderCashbook()")
);
assert.doesNotMatch(daybookColumnSource, /staffCollectionRegisterHtml/, "Cashbook must no longer contain the Staff Collection window");
assert.match(appSource, /Cashier: \[[^\]]*"approvals"/, "Cashier must have access to Staff Entry Approvals");
assert.match(appSource, /Executive: \[[^\]]*"approvals"/, "Executive must have access to Staff Entry Approvals");
assert.match(appSource, /Staff: \[[^\]]*"approvals"/, "Staff must be able to review their submitted entries");
assert.match(appSource, /if \(page === "approvals"\) renderRecoveryApprovals\(\)/, "Opening the separate approval page must render the approval queue");
assert.match(cssSource, /\.proposal-staff-section/, "Staff and group approval sections must have a clear grouped layout");

console.log("PASS: Staff Entry Approvals contains group approval and Staff Collection outside Cashbook");
