const fs = require("fs");
const vm = require("vm");
const assert = require("assert");
const path = require("path");
const JSZip = require("./vendor/jszip.min.js");
const recoveryXlsx = require("./recovery-demand-xlsx.js");

const appSource = fs.readFileSync(path.join(__dirname, "app.js"), "utf8");
const cssSource = fs.readFileSync(path.join(__dirname, "style.css"), "utf8");
const testableSource = appSource.slice(0, appSource.indexOf("window.editGroup = editGroup;"));
const storage = new Map();
const context = {
  console,
  Date,
  Map,
  Set,
  Blob,
  URL,
  setTimeout,
  clearTimeout,
  localStorage: {
    getItem: (key) => (storage.has(key) ? storage.get(key) : null),
    setItem: (key, value) => storage.set(key, String(value)),
  },
  document: { querySelector: () => null, querySelectorAll: () => [] },
  window: {},
};

vm.createContext(context);
vm.runInContext(`${testableSource}
  bankHolidays = [];
  const loan = { disbursedOn: "2026-06-01T00:00:00.000Z", day: "Monday", term: 26 };
  const individual = { amount: 10000, balance: 10000, emi: 1000, term: 26, penaltyBalance: 350 };
  const firstWeek = memberDemandSnapshot(loan, individual, "2026-06-08");
  const secondWeek = memberDemandSnapshot(loan, individual, "2026-06-15");
  const thirdWeek = memberDemandSnapshot(loan, individual, "2026-06-22");
  globalThis.__result = {
    firstCount: firstWeek.pendingEmiCount,
    secondCount: secondWeek.pendingEmiCount,
    thirdCount: thirdWeek.pendingEmiCount,
    thirdDemand: thirdWeek.demand,
    statusHtml: recoveryMemberStatusHtml({ ...thirdWeek, overdueDays: 14, npa: false }, individual),
  };
`, context);

assert.equal(context.__result.firstCount, 1, "First unpaid week should demand one EMI");
assert.equal(context.__result.secondCount, 2, "Next unpaid week should demand two EMIs");
assert.equal(context.__result.thirdCount, 3, "Second missed week should demand three EMIs");
assert.equal(context.__result.thirdDemand, 3000, "Recovery demand should contain only the three unpaid EMIs");
assert.match(context.__result.statusHtml, /3 EMI PENDING/);
assert.match(context.__result.statusHtml, /penalty/);
assert.match(appSource, /data-download-recovery-staff/, "Each staff row should provide an Excel download action");
assert.match(cssSource, /#downloadCsv\{display:none!important\}/, "The old page-level Excel button should be hidden");
assert.match(cssSource, /#balanceRecoveryFolder \.recovery-folder-account/, "Balance folder should use compact single-line rows");

(async () => {
  const workbook = await recoveryXlsx.buildRecoveryDemandWorkbook({
    sheets: [{
      name: "Staff Demand",
      title: "MONDAY TEST STAFF",
      groups: [{
        groupNumber: "G1",
        centreName: "Test Centre",
        firstEmi: "08/06/2026",
        loaningStaff: "Test Staff",
        recoveryStaff: "Test Staff",
        members: [
          { loanId: "A01", name: "Test Customer", mobile: "9999999999", emi: 1000, demand: 3000, penalty: 350, pendingEmiCount: 3, closed: false },
          { loanId: "A02", name: "Paid Customer", mobile: "8888888888", emi: 1000, demand: 0, penalty: 0, pendingEmiCount: 0, closed: false },
        ],
      }],
    }],
  });
  const zip = await JSZip.loadAsync(await workbook.arrayBuffer());
  const sheetXml = await zip.file("xl/worksheets/sheet1.xml").async("string");
  assert.match(sheetXml, /<v>3000<\/v>/, "Excel recovery amount should contain accumulated EMIs without penalty");
  assert.match(sheetXml, /3 EMI \+ PENALTY 350/, "Excel should tell staff the EMI count and penalty");
  assert.match(sheetXml, /r="F4"[^>]*><v>0<\/v>/, "Paid customer should show zero demand instead of one EMI");
  console.log("PASS: staff-wise Excel, accumulated EMI demand, and daily penalty display");
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
